import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

const api = axios.create({
  baseURL: API_URL,
  headers: { "Content-Type": "application/json" },
});

// Destination endpoints
export const getDestinations = (params = {}) =>
  api.get("/destinations", { params }).then((res) => res.data);

export const getDestinationById = (id) =>
  api.get(`/destinations/${id}`).then((res) => res.data);

export const createDestination = (payload) =>
  api.post("/destinations", payload).then((res) => res.data);

export const updateDestination = (id, payload) =>
  api.put(`/destinations/${id}`, payload).then((res) => res.data);

export const deleteDestination = (id) =>
  api.delete(`/destinations/${id}`).then((res) => res.data);

export default api;
