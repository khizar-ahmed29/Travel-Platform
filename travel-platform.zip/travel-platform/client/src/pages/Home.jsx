import { useEffect, useMemo, useState } from "react";
import Navbar from "../components/Navbar.jsx";
import Hero from "../components/Hero.jsx";
import DestinationsSection from "../components/DestinationsSection.jsx";
import FeaturedDestinations from "../components/FeaturedDestinations.jsx";
import Categories from "../components/Categories.jsx";
import About from "../components/About.jsx";
import Footer from "../components/Footer.jsx";
import {
  getDestinations,
  createDestination,
  updateDestination,
  deleteDestination,
} from "../services/api.js";

function Home() {
  const [allDestinations, setAllDestinations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [activeCategory, setActiveCategory] = useState("");

  const fetchAll = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await getDestinations();
      setAllDestinations(res.data || []);
    } catch (err) {
      setError(
        "Couldn't reach the backend API. Make sure the server is running on the configured VITE_API_URL."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const filteredDestinations = useMemo(() => {
    if (!activeCategory) return allDestinations;
    return allDestinations.filter((d) => d.category === activeCategory);
  }, [allDestinations, activeCategory]);

  const featured = useMemo(() => allDestinations.filter((d) => d.featured), [allDestinations]);

  const categories = useMemo(
    () => [...new Set(allDestinations.map((d) => d.category))],
    [allDestinations]
  );

  const categoryCounts = useMemo(() => {
    return allDestinations.reduce((acc, d) => {
      acc[d.category] = (acc[d.category] || 0) + 1;
      return acc;
    }, {});
  }, [allDestinations]);

  const stats = useMemo(
    () => ({
      destinationCount: allDestinations.length,
      countryCount: new Set(allDestinations.map((d) => d.country)).size,
      categoryCount: categories.length,
    }),
    [allDestinations, categories]
  );

  const handleCreate = async (payload) => {
    await createDestination(payload);
    await fetchAll();
  };

  const handleUpdate = async (id, payload) => {
    await updateDestination(id, payload);
    await fetchAll();
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this destination? This can't be undone.")) return;
    await deleteDestination(id);
    await fetchAll();
  };

  const jumpToCategory = (cat) => {
    setActiveCategory(cat);
    document.getElementById("destinations")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <Navbar />
      <main>
        <Hero stats={stats} />
        <DestinationsSection
          destinations={filteredDestinations}
          categories={categories}
          loading={loading}
          error={error}
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
          onCreate={handleCreate}
          onUpdate={handleUpdate}
          onDelete={handleDelete}
        />
        <FeaturedDestinations destinations={featured} loading={loading} />
        <Categories counts={categoryCounts} onSelect={jumpToCategory} />
        <About stats={stats} />
      </main>
      <Footer />
    </>
  );
}

export default Home;
