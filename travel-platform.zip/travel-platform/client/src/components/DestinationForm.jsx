import { useEffect, useState } from "react";

const CATEGORIES = [
  "Beach",
  "Mountain",
  "City",
  "Cultural",
  "Adventure",
  "Wildlife",
  "Historical",
  "Island",
];

const EMPTY = {
  name: "",
  country: "",
  city: "",
  description: "",
  imageUrl: "",
  category: "City",
  featured: false,
};

function DestinationForm({ initialData, onSubmit, onCancel, submitting }) {
  const [form, setForm] = useState(EMPTY);

  useEffect(() => {
    if (initialData) {
      setForm({ ...EMPTY, ...initialData });
    } else {
      setForm(EMPTY);
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((prev) => ({ ...prev, [name]: type === "checkbox" ? checked : value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <form className="dest-form" onSubmit={handleSubmit}>
      <div className="dest-form__grid">
        <label>
          Destination name
          <input name="name" value={form.name} onChange={handleChange} required placeholder="e.g. Lisbon" />
        </label>
        <label>
          Country
          <input name="country" value={form.country} onChange={handleChange} required placeholder="e.g. Portugal" />
        </label>
        <label>
          City / location
          <input name="city" value={form.city} onChange={handleChange} required placeholder="e.g. Lisbon District" />
        </label>
        <label>
          Category
          <select name="category" value={form.category} onChange={handleChange}>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>
        <label className="dest-form__wide">
          Image URL
          <input name="imageUrl" value={form.imageUrl} onChange={handleChange} required placeholder="https://..." />
        </label>
        <label className="dest-form__wide">
          Description
          <textarea
            name="description"
            value={form.description}
            onChange={handleChange}
            required
            rows={3}
            placeholder="What makes this destination worth visiting?"
          />
        </label>
        <label className="dest-form__checkbox">
          <input type="checkbox" name="featured" checked={form.featured} onChange={handleChange} />
          Mark as featured destination
        </label>
      </div>

      <div className="dest-form__actions">
        <button type="submit" className="btn btn--primary btn--sm" disabled={submitting}>
          {submitting ? "Saving..." : initialData ? "Save changes" : "Add destination"}
        </button>
        <button type="button" className="btn btn--ghost btn--sm" onClick={onCancel}>
          Cancel
        </button>
      </div>
    </form>
  );
}

export default DestinationForm;
