import { useState } from "react";
import DestinationCard from "./DestinationCard.jsx";
import DestinationForm from "./DestinationForm.jsx";
import StateMessage from "./StateMessage.jsx";

function DestinationsSection({
  destinations,
  categories,
  loading,
  error,
  activeCategory,
  onCategoryChange,
  onCreate,
  onUpdate,
  onDelete,
}) {
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const openCreate = () => {
    setEditing(null);
    setFormOpen(true);
  };

  const openEdit = (destination) => {
    setEditing(destination);
    setFormOpen(true);
    window.scrollTo({ top: document.getElementById("destinations").offsetTop - 90, behavior: "smooth" });
  };

  const closeForm = () => {
    setFormOpen(false);
    setEditing(null);
  };

  const handleSubmit = async (payload) => {
    setSubmitting(true);
    try {
      if (editing) {
        await onUpdate(editing._id, payload);
      } else {
        await onCreate(payload);
      }
      closeForm();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="section" id="destinations">
      <div className="section__inner">
        <div className="section__head">
          <p className="eyebrow">
            <span className="eyebrow__code">ALL</span> The full route map
          </p>
          <h2 className="section__title">Every destination, straight from the database</h2>
          <button type="button" className="btn btn--primary btn--sm" onClick={formOpen ? closeForm : openCreate}>
            {formOpen ? "Close form" : "Add a destination"}
          </button>
        </div>

        {formOpen && (
          <DestinationForm
            initialData={editing}
            onSubmit={handleSubmit}
            onCancel={closeForm}
            submitting={submitting}
          />
        )}

        <div className="pill-row" role="tablist" aria-label="Filter by category">
          <button
            className={`pill ${activeCategory === "" ? "pill--active" : ""}`}
            onClick={() => onCategoryChange("")}
          >
            All
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              className={`pill ${activeCategory === cat ? "pill--active" : ""}`}
              onClick={() => onCategoryChange(cat)}
            >
              {cat}
            </button>
          ))}
        </div>

        {loading && <StateMessage tone="info">Loading destinations…</StateMessage>}
        {error && <StateMessage tone="error">{error}</StateMessage>}
        {!loading && !error && destinations.length === 0 && (
          <StateMessage tone="info">No destinations yet — add the first one above.</StateMessage>
        )}

        <div className="ticket-grid">
          {destinations.map((dest) => (
            <DestinationCard
              key={dest._id}
              destination={dest}
              editable
              onEdit={openEdit}
              onDelete={onDelete}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

export default DestinationsSection;
