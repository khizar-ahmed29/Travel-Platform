import { toCode } from "../utils/code.js";

function DestinationCard({ destination, onEdit, onDelete, editable }) {
  const { name, country, city, description, imageUrl, category, featured, rating } = destination;

  return (
    <article className="ticket">
      <div className="ticket__image">
        <img src={imageUrl} alt={name} loading="lazy" />
        <span className="ticket__category">{category}</span>
        {featured && <span className="ticket__featured">Featured</span>}
      </div>

      <div className="ticket__stub">
        <div className="ticket__stub-top">
          <span className="mono ticket__code">{toCode(name)}</span>
          <span className="ticket__rating">★ {rating?.toFixed(1) ?? "4.5"}</span>
        </div>

        <h3 className="ticket__name">{name}</h3>
        <p className="ticket__place">
          {city}, {country}
        </p>
        <p className="ticket__desc">{description}</p>

        <div className="ticket__perf" aria-hidden="true">
          {Array.from({ length: 18 }).map((_, i) => (
            <span key={i} />
          ))}
        </div>

        <div className="ticket__footer">
          <span className="mono ticket__gate">GATE {String.fromCharCode(65 + (name.length % 6))}0{(name.length % 9) + 1}</span>
          {editable && (
            <div className="ticket__actions">
              <button type="button" onClick={() => onEdit(destination)} className="link-btn">
                Edit
              </button>
              <button type="button" onClick={() => onDelete(destination._id)} className="link-btn link-btn--danger">
                Delete
              </button>
            </div>
          )}
        </div>
      </div>
    </article>
  );
}

export default DestinationCard;
