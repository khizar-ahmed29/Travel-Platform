# Voyage — Travel & Tourism Experience Platform (Week 1)

A MERN-stack starter for a travel destination platform: React frontend, Express/Node API,
and MongoDB storage, wired together end-to-end.

```
travel-platform/
├── server/     Express + Mongoose API
└── client/     React (Vite) frontend
```

## What's included

**Frontend (`client/`)**
- Home page with Hero, Destinations (with category filter + add/edit/delete form),
  Featured Destinations, Travel Categories, and About sections
- All destination data comes from the backend API — nothing is hardcoded
- Custom design system (no UI library) themed around a boarding-pass / departures-board motif

**Backend (`server/`)**
- REST API for destinations: create, read (all + single), update, delete
- Mongoose model with validation
- Organized into `config/`, `models/`, `controllers/`, `routes/`
- Seed script with 9 real sample destinations

## 1. Set up MongoDB

Use either:
- **MongoDB Atlas** (free tier) — create a cluster, get a connection string, whitelist your IP
- **Local MongoDB** — install and run `mongod`, use `mongodb://localhost:27017/travelDB`

## 2. Run the backend

```bash
cd server
npm install
cp .env.example .env
# edit .env and paste your MONGO_URI
npm run seed   # optional: populates the database with 9 sample destinations
npm run dev    # starts the API on http://localhost:5000
```

Confirm it's working: open `http://localhost:5000` in a browser — you should see
`Travel Platform API is running`.

## 3. Run the frontend

```bash
cd client
npm install
cp .env.example .env
# defaults to http://localhost:5000/api, matching the backend above
npm run dev    # starts the app on http://localhost:5173
```

Open `http://localhost:5173` — the Destinations, Featured, and About sections will
populate from whatever is in your MongoDB database.

## API reference

| Method | Route                     | Description              |
|--------|---------------------------|---------------------------|
| GET    | `/api/destinations`       | List all destinations (supports `?category=` and `?featured=true`) |
| GET    | `/api/destinations/:id`   | Get a single destination |
| POST   | `/api/destinations`       | Create a destination     |
| PUT    | `/api/destinations/:id`   | Update a destination     |
| DELETE | `/api/destinations/:id`   | Delete a destination     |

### Destination shape

```json
{
  "name": "Santorini",
  "country": "Greece",
  "city": "Cyclades",
  "description": "Whitewashed villages cling to volcanic cliffs...",
  "imageUrl": "https://images.unsplash.com/...",
  "category": "Island",
  "featured": true,
  "rating": 4.9
}
```

`category` must be one of: `Beach`, `Mountain`, `City`, `Cultural`, `Adventure`,
`Wildlife`, `Historical`, `Island`.

## Troubleshooting

- **`querySrv ECONNREFUSED` / can't connect to Atlas** — usually a DNS issue with
  `mongodb+srv://` links on some networks. Try switching your DNS to `8.8.8.8`, or
  add `dns.setServers(["8.8.8.8"])` at the top of `server.js`, or use the non-SRV
  standard connection string from Atlas's "Drivers" connect screen.
- **Frontend shows "Couldn't reach the backend API"** — make sure the backend is
  running and `client/.env`'s `VITE_API_URL` matches its address/port.
- **CORS errors** — make sure `CLIENT_ORIGIN` in `server/.env` matches the URL the
  frontend is actually running on.

## Next steps (beyond Week 1)

- Authentication for who can add/edit/delete destinations
- Image upload instead of pasted image URLs
- Booking flow and reviews
- Pagination/search on the destinations list
