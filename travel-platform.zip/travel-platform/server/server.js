const express = require("express");
const cors = require("cors");
require("dotenv").config();
const connectDB = require("./config/db");
const destinationRoutes = require("./routes/destinationRoutes");

// Connect to MongoDB
connectDB();


const app = express();

const defaultOrigins = ["http://localhost:5173", "http://127.0.0.1:5173"];
const configuredOrigins = process.env.CLIENT_ORIGIN
  ? process.env.CLIENT_ORIGIN.split(",").map((o) => o.trim().replace(/\/$/, ""))
  : [];
const allowedOrigins = [...new Set([...defaultOrigins, ...configuredOrigins])];

// Middleware
app.use(
  cors({
    origin: allowedOrigins,
  })
);
app.use(express.json());

// Routes
app.get("/", (req, res) => {
  res.send("Travel Platform API is running");
});

app.use("/api/destinations", destinationRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: "Route not found" });
});

// Global error handler (catches anything thrown outside try/catch)
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: "Something went wrong on the server" });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
