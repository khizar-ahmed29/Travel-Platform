import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import DestinationCard from "../components/DestinationCard.jsx";
import StateMessage from "../components/StateMessage.jsx";
import { getDashboard, removeFavorite } from "../services/api.js";
import { useAuth } from "../context/AuthContext.jsx";

function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  const load = async () => {
    try {
      const res = await getDashboard();
      setData(res.data);
    } catch (err) {
      setError(err.response?.data?.message || "Could not load your dashboard");
    }
  };

  useEffect(() => { load(); }, []);

  const remove = async (id) => {
    await removeFavorite(id);
    load();
  };

  if (error) return <><Navbar /><main className="section"><StateMessage tone="error">{error}</StateMessage></main></>;

  if (!data) return <><Navbar /><main className="section"><StateMessage tone="info">Loading your dashboard…</StateMessage></main></>;

  const viewed = data.recentlyViewed.map((item) => item.destination).filter(Boolean);

  return (
    <>
      <Navbar />
      <main>
        <section className="dashboard-hero">
          <div>
            <p className="eyebrow eyebrow--light"><span className="eyebrow__code">DASH</span> Personal dashboard</p>
            <h1>Welcome back, {user?.name?.split(" ")[0] || "traveler"}.</h1>
            <p>Keep your favorite places close and discover your next destination.</p>
            <Link to="/profile" className="btn btn--ghost">Edit profile</Link>
          </div>
          <div className="dashboard-avatar">
            {data.user.profileImage ? <img src={data.user.profileImage} alt={data.user.name} /> : <span>{data.user.name?.charAt(0)?.toUpperCase()}</span>}
          </div>
        </section>

        <section className="section">
          <div className="dashboard-stats">
            <div><span>Saved destinations</span><strong>{data.statistics.favorites}</strong></div>
            <div><span>Places viewed</span><strong>{data.statistics.recentlyViewed}</strong></div>
            <div><span>Member since</span><strong>{new Date(data.statistics.memberSince).getFullYear()}</strong></div>
          </div>
        </section>

        <section className="section section--tint">
          <div className="section__inner">
            <div className="section__head">
              <p className="eyebrow"><span className="eyebrow__code">01</span> Your saves</p>
              <h2 className="section__title">Favorite destinations</h2>
            </div>
            {data.favorites.length ? (
              <div className="ticket-grid">
                {data.favorites.map((destination) => (
                  <div key={destination._id} className="dashboard-card-wrap">
                    <DestinationCard destination={destination} isFavorite />
                    <button className="link-btn link-btn--danger dashboard-remove" onClick={() => remove(destination._id)}>Remove from favorites</button>
                  </div>
                ))}
              </div>
            ) : <p className="state-msg state-msg--info">You haven't saved any destinations yet. <Link to="/#destinations">Explore destinations →</Link></p>}
          </div>
        </section>

        <section className="section">
          <div className="section__inner">
            <div className="section__head">
              <p className="eyebrow"><span className="eyebrow__code">02</span> Your activity</p>
              <h2 className="section__title">Recently viewed</h2>
            </div>
            {viewed.length ? <div className="ticket-grid">{viewed.map((destination) => <DestinationCard key={destination._id} destination={destination} />)}</div> : <p className="state-msg state-msg--info">Destinations you open while logged in will appear here.</p>}
          </div>
        </section>

        <section className="section section--tint">
          <div className="section__inner">
            <div className="section__head">
              <p className="eyebrow"><span className="eyebrow__code">03</span> Recommended</p>
              <h2 className="section__title">Featured for you</h2>
            </div>
            <div className="ticket-grid">{data.recommendations.map((destination) => <DestinationCard key={destination._id} destination={destination} />)}</div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

export default Dashboard;
