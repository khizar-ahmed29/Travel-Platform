import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const TOKEN_KEY = "voyage_token";

const api = axios.create({
  baseURL: API_URL,
  headers: { "Content-Type": "application/json" },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export const getDestinations = (params = {}) =>
  api.get("/destinations", { params }).then((res) => res.data);

export const getDestinationById = (id) =>
  api.get(`/destinations/${id}`).then((res) => res.data);

export const createDestination = (payload) =>
  api.post("/destinations", payload).then((res) => res.data);

export const updateDestination = (id, payload) =>
  api.put(`/destinations/${id}`, payload).then((res) => res.data);

export const deleteDestination = (id) =>
  api.delete(`/destinations/${id}`).then((res) => res.data);

export const getDashboard = () =>
  api.get("/users/dashboard").then((res) => res.data);

export const getFavorites = () =>
  api.get("/users/favorites").then((res) => res.data);

export const addFavorite = (destinationId) =>
  api.post(`/users/favorites/${destinationId}`).then((res) => res.data);

export const removeFavorite = (destinationId) =>
  api.delete(`/users/favorites/${destinationId}`).then((res) => res.data);

export const recordRecentlyViewed = (destinationId) =>
  api.post(`/users/recently-viewed/${destinationId}`).then((res) => res.data);

export const updateProfile = (payload) =>
  api.put("/users/profile", payload).then((res) => res.data);

export default api;
