# Voyage — Travel & Tourism Experience Platform

A MERN-stack travel destination platform: React frontend, Express/Node API, and
MongoDB storage, wired together end-to-end.

```
travel-platform/
├── server/     Express + Mongoose API
└── client/     React (Vite) frontend
```

## What's included

**Frontend (`client/`)**
- Home page with Hero, Destinations (search + category filter + sort + add/edit/delete),
  Featured Destinations, Travel Categories, and About sections
- Dedicated **Destination Details page** (`/destinations/:id`) via React Router
- Live search bar (debounced) and sort control (newest / top rated / most popular / name)
- All destination data comes from the backend API — nothing is hardcoded
- Loading, error, and empty-result states throughout
- Custom design system (no UI library) themed around a boarding-pass / departures-board motif

**Backend (`server/`)**
- REST API for destinations: create, read (all + single), update, delete
- Search (`?search=`), category filter (`?category=` or `/category/:category`), and sort
  (`?sort=rating|popularity|newest|name`)
- Mongoose model with validation, including `rating` and `popularity` fields
- Organized into `config/`, `models/`, `controllers/`, `routes/`
- Seed script with 9 sample destinations (including rating and popularity data)
- Connection retry logic to smooth over transient DNS/network blips

## 1. Set up MongoDB

Use either:
- **MongoDB Atlas** (free tier) — create a cluster, get a connection string, whitelist your IP
- **Local MongoDB** — install and run `mongod`, use `mongodb://localhost:27017/travelDB`

## 2. Run the backend

```bash
cd server
npm install
cp .env.example .env
# edit .env and paste your MONGO_URI
npm run seed   # optional: populates the database with 9 sample destinations
npm run dev    # starts the API on http://localhost:5000
```

Confirm it's working: open `http://localhost:5000` in a browser — you should see
`Travel Platform API is running`.

## 3. Run the frontend

```bash
cd client
npm install
cp .env.example .env
# defaults to http://localhost:5000/api, matching the backend above
npm run dev    # starts the app on http://localhost:5173
```

Open `http://localhost:5173` — the Destinations, Featured, and About sections will
populate from whatever is in your MongoDB database. Click any destination card to
open its full details page.

## API reference

| Method | Route                                | Description              |
|--------|---------------------------------------|---------------------------|
| GET    | `/api/destinations`                   | List destinations. Supports `?category=`, `?featured=true`, `?search=`, `?sort=` |
| GET    | `/api/destinations/category/:category`| List destinations in a single category |
| GET    | `/api/destinations/:id`               | Get a single destination |
| POST   | `/api/destinations`                   | Create a destination     |
| PUT    | `/api/destinations/:id`               | Update a destination     |
| DELETE | `/api/destinations/:id`               | Delete a destination     |

**Query parameters on `GET /api/destinations`:**
- `category` — exact category match (e.g. `?category=Beach`)
- `featured` — `true` to only return featured destinations
- `search` — case-insensitive match against name, country, or city
- `sort` — one of `newest` (default), `rating`, `popularity`, `name`

### Destination shape

```json
{
  "name": "Santorini",
  "country": "Greece",
  "city": "Cyclades",
  "description": "Whitewashed villages cling to volcanic cliffs...",
  "imageUrl": "https://images.unsplash.com/...",
  "category": "Island",
  "featured": true,
  "rating": 4.9,
  "popularity": 980
}
```

`category` must be one of: `Beach`, `Mountain`, `City`, `Cultural`, `Adventure`,
`Wildlife`, `Historical`, `Island`.

## Troubleshooting

- **`querySrv ECONNREFUSED` / can't connect to Atlas** — usually a DNS issue with
  `mongodb+srv://` links on some networks. `server/config/db.js` already retries
  3 times and forces Google/Cloudflare DNS, but if it persists, use the non-SRV
  standard connection string from Atlas's "Drivers" connect screen (select an
  older driver version to reveal it).
- **`bad auth: authentication failed`** — check `server/.env` for a literal
  `<password>` placeholder that wasn't replaced, or special characters in your
  password that need URL-encoding (e.g. `@` → `%40`).
- **CORS errors in the browser console** — `server/server.js` always allows
  `http://localhost:5173` by default; if you changed the frontend's port, update
  `CLIENT_ORIGIN` in `server/.env` and fully restart the backend (`Ctrl+C` then
  `npm run dev` — nodemon does not auto-restart on `.env` changes).
- **Frontend shows "Couldn't reach the backend API"** — make sure the backend is
  running and `client/.env`'s `VITE_API_URL` matches its address/port.

## Next steps

- Authentication for who can add/edit/delete destinations
- Image upload instead of pasted image URLs
- Booking flow and reviews
- Pagination on the destinations list
