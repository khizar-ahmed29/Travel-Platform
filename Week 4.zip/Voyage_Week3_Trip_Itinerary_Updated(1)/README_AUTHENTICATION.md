# Voyage — Authentication & Personalized Dashboard

This update adds:

- User registration, login and logout
- JWT authentication with bcrypt password hashing
- User profile: name, email, profile image URL and bio
- Favorite destinations: save, remove and view
- Personalized dashboard
- Recently viewed destinations for logged-in users
- Featured recommendations
- User statistics
- Protected Dashboard, Favorites and Profile routes
- Axios auth interceptor
- Responsive authentication/dashboard UI

## Setup

### 1. Server

From `server/`:

```bash
npm install
```

Create `server/.env` from `.env.example` and set:

```env
MONGO_URI=your_mongodb_connection_string
PORT=5000
CLIENT_ORIGIN=http://localhost:5173
JWT_SECRET=use_a_long_random_secret
JWT_EXPIRES_IN=7d
```

Run:

```bash
npm run dev
```

### 2. Client

From `client/`:

```bash
npm install
npm run dev
```

If needed, create `client/.env`:

```env
VITE_API_URL=http://localhost:5000/api
```

## Routes

Public:
- `/`
- `/destinations/:id`
- `/login`
- `/register`

Protected:
- `/dashboard`
- `/favorites`
- `/profile`

The project zip intentionally excludes `.env` files and `node_modules`. Copy the provided `.env.example` files and add your own credentials.


## Trip & Itinerary Management

The platform now also includes authenticated trip planning:

- Create, view, edit and delete your own trips
- Automatic day-by-day itinerary generation from trip dates
- Add, update, move between days, and delete activities
- Activity title, location, date, time, category and description
- Trip status: upcoming, ongoing, completed or cancelled
- Dedicated `/trips` trip dashboard with statistics
- Dedicated `/trips/:id` itinerary editor
- Protected REST APIs under `/api/trips`
