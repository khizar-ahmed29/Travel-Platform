// Derives a 3-letter "airport style" code from a destination name,
// used as the signature visual motif on boarding-pass style cards.
export const toCode = (name = "") => {
  const cleaned = name.replace(/[^a-zA-Z ]/g, "");
  const words = cleaned.split(" ").filter(Boolean);
  if (words.length >= 2) {
    return (words[0][0] + words[1][0] + words[0][1]).toUpperCase();
  }
  return cleaned.slice(0, 3).toUpperCase().padEnd(3, "X");
};
