import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import { useAuth } from "../context/AuthContext.jsx";

function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", profileImage: "", bio: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await register(form);
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || "Unable to create account");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Navbar />
      <main className="auth-shell">
        <form className="auth-card auth-card--wide" onSubmit={submit}>
          <p className="eyebrow"><span className="eyebrow__code">02</span> Join Voyage</p>
          <h1 className="section__title">Create your account</h1>
          <p className="section__sub">Save places you love and get recommendations based on your travel activity.</p>
          {error && <p className="state-msg state-msg--error">{error}</p>}
          <div className="auth-grid">
            <label className="form-field">Name<input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label>
            <label className="form-field">Email<input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label>
            <label className="form-field">Password<input type="password" required minLength="6" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></label>
            <label className="form-field">Profile image URL<input type="url" placeholder="https://…" value={form.profileImage} onChange={(e) => setForm({ ...form, profileImage: e.target.value })} /></label>
            <label className="form-field auth-field-wide">Bio<textarea rows="3" maxLength="500" placeholder="Tell travelers a little about you…" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} /></label>
          </div>
          <button className="btn btn--primary" disabled={loading}>{loading ? "Creating account…" : "Create account"}</button>
          <p className="auth-switch">Already registered? <Link to="/login">Log in</Link></p>
        </form>
      </main>
    </>
  );
}

export default Register;
