import { useEffect, useState } from "react";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import StateMessage from "../components/StateMessage.jsx";
import { updateProfile } from "../services/api.js";
import { useAuth } from "../context/AuthContext.jsx";

function Profile() {
  const { user, setUser } = useAuth();
  const [form, setForm] = useState({ name: "", profileImage: "", bio: "" });
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (user) setForm({ name: user.name || "", profileImage: user.profileImage || "", bio: user.bio || "" });
  }, [user]);

  const submit = async (e) => {
    e.preventDefault();
    setMessage("");
    setError("");
    try {
      const res = await updateProfile(form);
      setUser(res.user);
      setMessage("Profile updated successfully.");
    } catch (err) {
      setError(err.response?.data?.message || "Could not update profile");
    }
  };

  return (
    <>
      <Navbar />
      <main className="auth-shell">
        <form className="auth-card auth-card--wide" onSubmit={submit}>
          <p className="eyebrow"><span className="eyebrow__code">PROFILE</span> Your details</p>
          <h1 className="section__title">Profile</h1>
          <p className="section__sub">Update the information shown on your personalized account.</p>
          {message && <StateMessage tone="info">{message}</StateMessage>}
          {error && <StateMessage tone="error">{error}</StateMessage>}
          <div className="profile-preview">
            {form.profileImage ? <img src={form.profileImage} alt="Profile preview" /> : <span>{form.name?.charAt(0)?.toUpperCase() || "V"}</span>}
          </div>
          <label className="form-field">Name<input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label>
          <label className="form-field">Email<input disabled value={user?.email || ""} /></label>
          <label className="form-field">Profile image URL<input type="url" value={form.profileImage} onChange={(e) => setForm({ ...form, profileImage: e.target.value })} /></label>
          <label className="form-field">Bio<textarea rows="5" maxLength="500" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} /></label>
          <button className="btn btn--primary">Save changes</button>
        </form>
      </main>
      <Footer />
    </>
  );
}

export default Profile;
