import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import TripForm from "../components/TripForm.jsx";
import StateMessage from "../components/StateMessage.jsx";
import { addActivity, deleteActivity, deleteTrip, getTrip, updateActivity, updateTrip } from "../services/api.js";

const emptyActivity = { dayNumber: 1, title: "", location: "", date: "", time: "", category: "Sightseeing", description: "" };

const formatDate = (value, options = { weekday: "short", day: "numeric", month: "short" }) =>
  new Date(value).toLocaleDateString(undefined, options);

function TripDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [trip, setTrip] = useState(null);
  const [editingTrip, setEditingTrip] = useState(false);
  const [activityForm, setActivityForm] = useState(emptyActivity);
  const [editingActivity, setEditingActivity] = useState(null);
  const [error, setError] = useState("");

  const load = async () => {
    try {
      const res = await getTrip(id);
      setTrip(res.data);
    } catch (err) {
      setError(err.response?.data?.message || "Could not load this trip.");
    }
  };

  useEffect(() => { load(); }, [id]);

  const tripDays = useMemo(() => {
    if (!trip) return 0;
    return Math.max(1, Math.ceil((new Date(trip.endDate) - new Date(trip.startDate)) / 86400000) + 1);
  }, [trip]);

  const beginActivity = (day) => {
    setEditingActivity(null);
    setActivityForm({
      ...emptyActivity,
      dayNumber: day.dayNumber,
      date: new Date(day.date).toISOString().slice(0, 10),
    });
  };

  const editActivity = (day, activity) => {
    setEditingActivity({ dayNumber: day.dayNumber, id: activity._id });
    setActivityForm({
      dayNumber: day.dayNumber,
      title: activity.title,
      location: activity.location || "",
      date: new Date(activity.date).toISOString().slice(0, 10),
      time: activity.time || "",
      category: activity.category || "Other",
      description: activity.description || "",
    });
  };

  const submitActivity = async (e) => {
    e.preventDefault();
    setError("");
    try {
      if (editingActivity) {
        await updateActivity(id, editingActivity.id, activityForm);
      } else {
        await addActivity(id, activityForm);
      }
      setActivityForm(emptyActivity);
      setEditingActivity(null);
      await load();
    } catch (err) {
      setError(err.response?.data?.message || "Could not save activity.");
    }
  };

  const removeActivity = async (activityId) => {
    if (!window.confirm("Delete this activity?")) return;
    await deleteActivity(id, activityId);
    load();
  };

  const removeTrip = async () => {
    if (!window.confirm("Delete this trip and its entire itinerary?")) return;
    await deleteTrip(id);
    navigate("/trips");
  };

  const saveTrip = async (payload) => {
    await updateTrip(id, payload);
    setEditingTrip(false);
    await load();
  };

  if (error && !trip) return <><Navbar /><main className="section"><StateMessage tone="error">{error}</StateMessage></main></>;
  if (!trip) return <><Navbar /><main className="section"><StateMessage tone="info">Loading trip…</StateMessage></main></>;

  const tripInitial = {
    tripName: trip.tripName,
    destination: trip.destination,
    startDate: new Date(trip.startDate).toISOString().slice(0, 10),
    endDate: new Date(trip.endDate).toISOString().slice(0, 10),
    travelers: trip.travelers,
    description: trip.description || "",
  };

  return (
    <>
      <Navbar />
      <main>
        <section className="trip-detail-hero">
          <div>
            <Link to="/trips" className="trip-back">← All trips</Link>
            <div className="trip-card__top">
              <span className={`trip-status trip-status--${trip.status}`}>{trip.status}</span>
              <span className="mono">{tripDays} DAYS · {trip.travelers} TRAVELER{trip.travelers === 1 ? "" : "S"}</span>
            </div>
            <h1>{trip.tripName}</h1>
            <p>📍 {trip.destination} · {formatDate(trip.startDate, { day: "numeric", month: "long", year: "numeric" })} — {formatDate(trip.endDate, { day: "numeric", month: "long", year: "numeric" })}</p>
          </div>
          <div className="trip-detail-actions">
            <button className="btn btn--ghost" onClick={() => setEditingTrip((v) => !v)}>{editingTrip ? "Close editor" : "Edit trip"}</button>
            <button className="btn btn--danger" onClick={removeTrip}>Delete trip</button>
          </div>
        </section>

        {error && <div className="section section--compact"><StateMessage tone="error">{error}</StateMessage></div>}

        {editingTrip && (
          <section className="section section--compact">
            <div className="section__inner">
              <TripForm initialValues={tripInitial} onSubmit={saveTrip} onCancel={() => setEditingTrip(false)} submitLabel="Save trip changes" />
            </div>
          </section>
        )}

        <section className="section">
          <div className="section__inner">
            <div className="itinerary-head">
              <div>
                <p className="eyebrow"><span className="eyebrow__code">ITIN</span> Day-by-day plan</p>
                <h2 className="section__title">Your itinerary</h2>
                <p className="section__sub">{trip.description || "Add activities below to turn your trip into a detailed plan."}</p>
              </div>
              <span className="itinerary-count">{trip.itinerary.reduce((n, d) => n + d.activities.length, 0)} activities</span>
            </div>

            <div className="itinerary">
              {trip.itinerary.map((day) => (
                <article className="itinerary-day" key={day.dayNumber}>
                  <header className="itinerary-day__header">
                    <div>
                      <span className="eyebrow"><span className="eyebrow__code">DAY {String(day.dayNumber).padStart(2, "0")}</span></span>
                      <h3>{formatDate(day.date, { weekday: "long", day: "numeric", month: "long" })}</h3>
                    </div>
                    <button className="btn btn--primary btn--sm" onClick={() => beginActivity(day)}>+ Add activity</button>
                  </header>

                  {day.activities.length ? (
                    <div className="activity-list">
                      {day.activities.map((activity) => (
                        <div className="activity-item" key={activity._id}>
                          <div className="activity-item__time">{activity.time || "Flexible"}</div>
                          <div className="activity-item__body">
                            <span className="activity-category">{activity.category}</span>
                            <h4>{activity.title}</h4>
                            {activity.location && <p>📍 {activity.location}</p>}
                            {activity.description && <p>{activity.description}</p>}
                          </div>
                          <div className="activity-item__actions">
                            <button className="link-btn" onClick={() => editActivity(day, activity)}>Edit</button>
                            <button className="link-btn link-btn--danger" onClick={() => removeActivity(activity._id)}>Delete</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : <p className="empty-day">No activities planned for this day yet.</p>}
                </article>
              ))}
            </div>
          </div>
        </section>

        {(editingActivity || activityForm.date) && (
          <section className="section section--tint">
            <div className="section__inner">
              <div className="section__head">
                <p className="eyebrow"><span className="eyebrow__code">ACTIVITY</span> Itinerary editor</p>
                <h2 className="section__title">{editingActivity ? "Edit activity" : "Add an activity"}</h2>
              </div>
              <form className="trip-form" onSubmit={submitActivity}>
                <div className="trip-form__grid">
                  <label>Day<select value={activityForm.dayNumber} onChange={(e) => {
                    const dayNumber = Number(e.target.value);
                    const day = trip.itinerary.find((d) => d.dayNumber === dayNumber);
                    setActivityForm((p) => ({ ...p, dayNumber, date: new Date(day.date).toISOString().slice(0, 10) }));
                  }}>{trip.itinerary.map((day) => <option key={day.dayNumber} value={day.dayNumber}>Day {day.dayNumber} — {formatDate(day.date, { day: "numeric", month: "short" })}</option>)}</select></label>
                  <label>Activity title<input required value={activityForm.title} onChange={(e) => setActivityForm({ ...activityForm, title: e.target.value })} placeholder="Visit Hagia Sophia" /></label>
                  <label>Location<input value={activityForm.location} onChange={(e) => setActivityForm({ ...activityForm, location: e.target.value })} placeholder="Sultanahmet" /></label>
                  <label>Date<input required type="date" value={activityForm.date} min={new Date(trip.startDate).toISOString().slice(0, 10)} max={new Date(trip.endDate).toISOString().slice(0, 10)} onChange={(e) => setActivityForm({ ...activityForm, date: e.target.value })} /></label>
                  <label>Time<input type="time" value={activityForm.time} onChange={(e) => setActivityForm({ ...activityForm, time: e.target.value })} /></label>
                  <label>Category<select value={activityForm.category} onChange={(e) => setActivityForm({ ...activityForm, category: e.target.value })}>
                    {["Sightseeing", "Food", "Adventure", "Culture", "Shopping", "Transport", "Relaxation", "Other"].map((x) => <option key={x}>{x}</option>)}
                  </select></label>
                  <label className="trip-form__wide">Description<textarea rows="4" maxLength="600" value={activityForm.description} onChange={(e) => setActivityForm({ ...activityForm, description: e.target.value })} placeholder="Add notes, reservations, reminders, etc." /></label>
                </div>
                <div className="trip-form__actions">
                  <button className="btn btn--primary">{editingActivity ? "Update activity" : "Add activity"}</button>
                  <button type="button" className="btn btn--ghost" onClick={() => { setActivityForm(emptyActivity); setEditingActivity(null); }}>Cancel</button>
                </div>
              </form>
            </div>
          </section>
        )}
      </main>
      <Footer />
    </>
  );
}

export default TripDetails;
