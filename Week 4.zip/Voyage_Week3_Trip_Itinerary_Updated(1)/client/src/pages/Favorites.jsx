import { useEffect, useState } from "react";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import DestinationCard from "../components/DestinationCard.jsx";
import StateMessage from "../components/StateMessage.jsx";
import { getFavorites, removeFavorite } from "../services/api.js";

function Favorites() {
  const [favorites, setFavorites] = useState(null);
  const [error, setError] = useState("");

  const load = async () => {
    try {
      const res = await getFavorites();
      setFavorites(res.data);
    } catch (err) {
      setError(err.response?.data?.message || "Could not load favorites");
    }
  };

  useEffect(() => { load(); }, []);

  const remove = async (id) => {
    await removeFavorite(id);
    load();
  };

  return (
    <>
      <Navbar />
      <main className="section">
        <div className="section__inner">
          <div className="section__head">
            <p className="eyebrow"><span className="eyebrow__code">SAVED</span> Your collection</p>
            <h1 className="section__title">Favorite destinations</h1>
          </div>
          {error && <StateMessage tone="error">{error}</StateMessage>}
          {!favorites && !error && <StateMessage tone="info">Loading favorites…</StateMessage>}
          {favorites && !favorites.length && <StateMessage tone="info">No saved destinations yet.</StateMessage>}
          {favorites && favorites.length > 0 && (
            <div className="ticket-grid">
              {favorites.map((destination) => (
                <div key={destination._id} className="dashboard-card-wrap">
                  <DestinationCard destination={destination} isFavorite />
                  <button className="link-btn link-btn--danger dashboard-remove" onClick={() => remove(destination._id)}>Remove from favorites</button>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}

export default Favorites;
