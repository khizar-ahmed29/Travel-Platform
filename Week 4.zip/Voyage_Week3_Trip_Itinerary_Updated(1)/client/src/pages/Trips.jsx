import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import TripForm from "../components/TripForm.jsx";
import StateMessage from "../components/StateMessage.jsx";
import { createTrip, deleteTrip, getTrips } from "../services/api.js";

const formatDate = (value) => new Date(value).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });

const daysBetween = (start, end) =>
  Math.max(1, Math.ceil((new Date(end) - new Date(start)) / 86400000) + 1);

function Trips() {
  const [trips, setTrips] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");

  const load = async () => {
    try {
      const res = await getTrips();
      setTrips(res.data);
    } catch (err) {
      setError(err.response?.data?.message || "Could not load your trips.");
    }
  };

  useEffect(() => { load(); }, []);

  const upcoming = useMemo(() => trips.filter((t) => t.status === "upcoming" || t.status === "ongoing"), [trips]);
  const completed = useMemo(() => trips.filter((t) => t.status === "completed"), [trips]);
  const totalDays = useMemo(() => trips.reduce((sum, t) => sum + daysBetween(t.startDate, t.endDate), 0), [trips]);

  const submit = async (payload) => {
    await createTrip(payload);
    setShowForm(false);
    await load();
  };

  const remove = async (id) => {
    if (!window.confirm("Delete this trip and its itinerary? This cannot be undone.")) return;
    await deleteTrip(id);
    load();
  };

  const renderTrip = (trip) => (
    <article className="trip-card" key={trip._id}>
      <div className="trip-card__top">
        <span className={`trip-status trip-status--${trip.status}`}>{trip.status}</span>
        <span className="mono trip-card__code">{trip.destination.slice(0, 3).toUpperCase()}</span>
      </div>
      <h3>{trip.tripName}</h3>
      <p className="trip-card__destination">{trip.destination}</p>
      <p className="trip-card__dates">{formatDate(trip.startDate)} — {formatDate(trip.endDate)}</p>
      <div className="trip-card__meta">
        <span>👥 {trip.travelers} traveler{trip.travelers === 1 ? "" : "s"}</span>
        <span>🗓 {daysBetween(trip.startDate, trip.endDate)} days</span>
        <span>📍 {trip.itinerary.reduce((n, d) => n + d.activities.length, 0)} activities</span>
      </div>
      <div className="trip-card__actions">
        <Link className="btn btn--primary btn--sm" to={`/trips/${trip._id}`}>Open itinerary</Link>
        <button className="link-btn link-btn--danger" onClick={() => remove(trip._id)}>Delete</button>
      </div>
    </article>
  );

  return (
    <>
      <Navbar />
      <main>
        <section className="trip-hero">
          <div>
            <p className="eyebrow eyebrow--light"><span className="eyebrow__code">TRIPS</span> Trip planner</p>
            <h1>Plan the journey, not just the destination.</h1>
            <p>Create trips, build day-by-day itineraries, and keep every activity organized in one place.</p>
          </div>
          <button className="btn btn--primary" onClick={() => setShowForm((v) => !v)}>
            {showForm ? "Close planner" : "+ Create a trip"}
          </button>
        </section>

        {showForm && (
          <section className="section">
            <div className="section__inner">
              <div className="section__head">
                <p className="eyebrow"><span className="eyebrow__code">01</span> New plan</p>
                <h2 className="section__title">Create your trip</h2>
              </div>
              <TripForm onSubmit={submit} onCancel={() => setShowForm(false)} />
            </div>
          </section>
        )}

        {error && <div className="section"><StateMessage tone="error">{error}</StateMessage></div>}

        <section className="section section--tint">
          <div className="section__inner">
            <div className="trip-summary-grid">
              <div><span>Number of trips</span><strong>{trips.length}</strong></div>
              <div><span>Upcoming trips</span><strong>{upcoming.length}</strong></div>
              <div><span>Total planned days</span><strong>{totalDays}</strong></div>
              <div><span>Completed trips</span><strong>{completed.length}</strong></div>
            </div>
          </div>
        </section>

        <section className="section">
          <div className="section__inner">
            <div className="section__head">
              <p className="eyebrow"><span className="eyebrow__code">02</span> Next departures</p>
              <h2 className="section__title">Upcoming trips</h2>
            </div>
            {upcoming.length ? <div className="trip-grid">{upcoming.map(renderTrip)}</div> : <StateMessage tone="info">No upcoming trips. Create your next adventure above.</StateMessage>}
          </div>
        </section>

        <section className="section">
          <div className="section__inner">
            <div className="section__head">
              <p className="eyebrow"><span className="eyebrow__code">03</span> Recent plans</p>
              <h2 className="section__title">Recent trips</h2>
            </div>
            {trips.length ? <div className="trip-grid">{[...trips].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 3).map(renderTrip)}</div> : <StateMessage tone="info">Your recent trips will appear here.</StateMessage>}
          </div>
        </section>

        <section className="section section--tint">
          <div className="section__inner">
            <div className="section__head">
              <p className="eyebrow"><span className="eyebrow__code">04</span> Your history</p>
              <h2 className="section__title">Completed trips</h2>
            </div>
            {completed.length ? <div className="trip-grid">{completed.map(renderTrip)}</div> : <StateMessage tone="info">Completed trips will appear here after their end date.</StateMessage>}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

export default Trips;
