import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import { useAuth } from "../context/AuthContext.jsx";

function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(form);
      navigate(location.state?.from?.pathname || "/dashboard", { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || "Unable to log in");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Navbar />
      <main className="auth-shell">
        <form className="auth-card" onSubmit={submit}>
          <p className="eyebrow"><span className="eyebrow__code">01</span> Welcome back</p>
          <h1 className="section__title">Log in to Voyage</h1>
          <p className="section__sub">Access your saved destinations and personalized travel dashboard.</p>
          {error && <p className="state-msg state-msg--error">{error}</p>}
          <label className="form-field">
            Email
            <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </label>
          <label className="form-field">
            Password
            <input type="password" required minLength="6" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </label>
          <button className="btn btn--primary" disabled={loading}>{loading ? "Logging in…" : "Log in"}</button>
          <p className="auth-switch">Don't have an account? <Link to="/register">Create one</Link></p>
        </form>
      </main>
    </>
  );
}

export default Login;
