import { useEffect, useState } from "react";

function SearchBar({ value, onChange, placeholder = "Search by name, city, or country…" }) {
  const [localValue, setLocalValue] = useState(value);

  // Debounce: only push the search term up (and trigger an API call) 350ms
  // after the user stops typing, instead of on every keystroke.
  useEffect(() => {
    const timeout = setTimeout(() => {
      if (localValue !== value) onChange(localValue);
    }, 350);
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [localValue]);

  useEffect(() => {
    setLocalValue(value);
  }, [value]);

  return (
    <div className="search-bar">
      <svg className="search-bar__icon" viewBox="0 0 20 20" width="16" height="16" fill="none" aria-hidden="true">
        <circle cx="9" cy="9" r="6.5" stroke="currentColor" strokeWidth="1.5" />
        <path d="M18 18 14 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      </svg>
      <input
        type="text"
        value={localValue}
        onChange={(e) => setLocalValue(e.target.value)}
        placeholder={placeholder}
        aria-label="Search destinations"
      />
      {localValue && (
        <button
          type="button"
          className="search-bar__clear"
          onClick={() => setLocalValue("")}
          aria-label="Clear search"
        >
          ×
        </button>
      )}
    </div>
  );
}

export default SearchBar;
