import { Link } from "react-router-dom";
import { toCode } from "../utils/code.js";
import { useAuth } from "../context/AuthContext.jsx";
import { addFavorite, removeFavorite } from "../services/api.js";
import { useEffect, useState } from "react";

function DestinationCard({ destination, onEdit, onDelete, editable, isFavorite = false }) {
  const { user } = useAuth();
  const { _id, name, country, city, description, imageUrl, category, featured, rating, popularity } = destination;
  const [saved, setSaved] = useState(isFavorite);

  useEffect(() => {
    if (user && isFavorite) setSaved(true);
    if (!user) {
      const raw = localStorage.getItem("voyage_favorites");
      if (raw) {
        try { setSaved(JSON.parse(raw).includes(_id)); } catch {}
      }
    }
  }, [_id, user, isFavorite]);

  const toggleFavorite = async () => {
    if (!user) return;
    try {
      if (saved) {
        await removeFavorite(_id);
        setSaved(false);
      } else {
        await addFavorite(_id);
        setSaved(true);
      }
      const raw = JSON.parse(localStorage.getItem("voyage_favorites") || "[]");
      const next = saved ? raw.filter((id) => id !== _id) : [...new Set([...raw, _id])];
      localStorage.setItem("voyage_favorites", JSON.stringify(next));
    } catch {}
  };

  return (
    <article className="ticket">
      <Link to={`/destinations/${_id}`} className="ticket__image">
        <img src={imageUrl} alt={name} loading="lazy" />
        <span className="ticket__category">{category}</span>
        {featured && <span className="ticket__featured">Featured</span>}
      </Link>

      <div className="ticket__stub">
        <div className="ticket__stub-top">
          <span className="mono ticket__code">{toCode(name)}</span>
          <span className="ticket__rating">★ {rating?.toFixed(1) ?? "4.5"}</span>
        </div>

        <Link to={`/destinations/${_id}`}><h3 className="ticket__name">{name}</h3></Link>
        <p className="ticket__place">{city}, {country}</p>
        <p className="ticket__desc">{description}</p>

        {typeof popularity === "number" && <p className="ticket__popularity mono">🔥 {popularity.toLocaleString()} travelers this month</p>}

        <div className="ticket__perf" aria-hidden="true">{Array.from({ length: 18 }).map((_, i) => <span key={i} />)}</div>

        <div className="ticket__footer">
          {user ? (
            <button type="button" className={`favorite-btn ${saved ? "favorite-btn--saved" : ""}`} onClick={toggleFavorite}>
              {saved ? "♥ Saved" : "♡ Save"}
            </button>
          ) : <Link className="link-btn" to="/login">Log in to save</Link>}

          {editable && (
            <div className="ticket__actions">
              <button type="button" onClick={() => onEdit(destination)} className="link-btn">Edit</button>
              <button type="button" onClick={() => onDelete(_id)} className="link-btn link-btn--danger">Delete</button>
            </div>
          )}
        </div>
      </div>
    </article>
  );
}

export default DestinationCard;
