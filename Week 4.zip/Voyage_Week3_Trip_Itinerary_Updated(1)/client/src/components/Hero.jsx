function Hero({ stats }) {
  const { destinationCount = 0, countryCount = 0, categoryCount = 0 } = stats || {};

  return (
    <section className="hero" id="top">
      <div className="hero__inner">
        <div className="hero__copy">
          <p className="eyebrow">
            <span className="eyebrow__code">DEP</span> Journeys worth boarding for
          </p>
          <h1 className="hero__title">
            Find the place you haven't
            <br />
            <em>been dreaming</em> about yet.
          </h1>
          <p className="hero__sub">
            Voyage curates real destinations, sourced straight from our database, so every
            place you browse here is one you can actually plan a trip to.
          </p>

          <div className="hero__actions">
            <a href="#destinations" className="btn btn--primary">
              Browse destinations
            </a>
            <a href="#featured" className="btn btn--ghost">
              See what's featured
            </a>
          </div>

          <dl className="hero__stats" aria-label="Platform statistics">
            <div className="hero__stat">
              <dt>Destinations</dt>
              <dd>{String(destinationCount).padStart(2, "0")}</dd>
            </div>
            <div className="hero__stat">
              <dt>Countries</dt>
              <dd>{String(countryCount).padStart(2, "0")}</dd>
            </div>
            <div className="hero__stat">
              <dt>Categories</dt>
              <dd>{String(categoryCount).padStart(2, "0")}</dd>
            </div>
          </dl>
        </div>

        <div className="hero__board" aria-hidden="true">
          <div className="board">
            <div className="board__row board__row--head">
              <span>CODE</span>
              <span>DESTINATION</span>
              <span>STATUS</span>
            </div>
            <div className="board__row">
              <span className="mono">SNT</span>
              <span>Santorini, GR</span>
              <span className="board__status board__status--on">On Time</span>
            </div>
            <div className="board__row">
              <span className="mono">KYT</span>
              <span>Kyoto, JP</span>
              <span className="board__status board__status--on">On Time</span>
            </div>
            <div className="board__row">
              <span className="mono">BOR</span>
              <span>Bora Bora, PF</span>
              <span className="board__status board__status--board">Boarding</span>
            </div>
            <div className="board__row">
              <span className="mono">MCH</span>
              <span>Machu Picchu, PE</span>
              <span className="board__status board__status--on">On Time</span>
            </div>
          </div>
          <svg className="hero__route" viewBox="0 0 340 200" fill="none">
            <path
              d="M10 190 C 90 40, 180 220, 330 20"
              stroke="var(--gold)"
              strokeWidth="1.5"
              strokeDasharray="2 8"
              strokeLinecap="round"
            />
            <circle cx="10" cy="190" r="4" fill="var(--coral)" />
            <circle cx="330" cy="20" r="4" fill="var(--teal)" />
          </svg>
        </div>
      </div>
    </section>
  );
}

export default Hero;
