import DestinationCard from "./DestinationCard.jsx";
import StateMessage from "./StateMessage.jsx";

function FeaturedDestinations({ destinations, loading }) {
  return (
    <section className="section section--tint" id="featured">
      <div className="section__inner">
        <div className="section__head">
          <p className="eyebrow">
            <span className="eyebrow__code">STAR</span> Handpicked by us
          </p>
          <h2 className="section__title">Featured this season</h2>
          <p className="section__sub">
            Marked <em>featured</em> in the database — the destinations we'd book a ticket for tomorrow.
          </p>
        </div>

        {loading && <StateMessage tone="info">Loading featured picks…</StateMessage>}
        {!loading && destinations.length === 0 && (
          <StateMessage tone="info">No featured destinations yet. Mark one as featured from the form above.</StateMessage>
        )}

        <div className="ticket-grid ticket-grid--featured">
          {destinations.map((dest) => (
            <DestinationCard key={dest._id} destination={dest} />
          ))}
        </div>
      </div>
    </section>
  );
}

export default FeaturedDestinations;
