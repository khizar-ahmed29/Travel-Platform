const CATEGORY_META = {
  Beach: { icon: "🏖", tag: "SUN" },
  Mountain: { icon: "⛰", tag: "ALT" },
  City: { icon: "🏙", tag: "URB" },
  Cultural: { icon: "🏺", tag: "CUL" },
  Adventure: { icon: "🧭", tag: "ADV" },
  Wildlife: { icon: "🦁", tag: "WLD" },
  Historical: { icon: "🏛", tag: "HIS" },
  Island: { icon: "🌴", tag: "ISL" },
};

function Categories({ counts, onSelect }) {
  const categories = Object.keys(CATEGORY_META);

  return (
    <section className="section" id="categories">
      <div className="section__inner">
        <div className="section__head">
          <p className="eyebrow">
            <span className="eyebrow__code">NAV</span> Choose your route
          </p>
          <h2 className="section__title">Travel by category</h2>
          <p className="section__sub">Jump straight to the kind of trip you're in the mood for.</p>
        </div>

        <div className="cat-grid">
          {categories.map((cat) => (
            <button key={cat} className="cat-card" onClick={() => onSelect(cat)}>
              <span className="cat-card__icon" aria-hidden="true">
                {CATEGORY_META[cat].icon}
              </span>
              <span className="mono cat-card__tag">{CATEGORY_META[cat].tag}</span>
              <span className="cat-card__name">{cat}</span>
              <span className="cat-card__count">{counts[cat] || 0} destinations</span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Categories;
