function About({ stats }) {
  const { destinationCount = 0, countryCount = 0, categoryCount = 0 } = stats || {};

  return (
    <section className="section section--dark" id="about">
      <div className="section__inner about">
        <div className="about__copy">
          <p className="eyebrow eyebrow--light">
            <span className="eyebrow__code">ABT</span> Why Voyage
          </p>
          <h2 className="section__title section__title--light">
            Built for people who plan trips, not just dream about them.
          </h2>
          <p className="about__text">
            Voyage started as a simple idea: most travel sites bury real places under ads and
            sponsored placements. We keep it plain — every destination on this platform lives in
            our own database, tagged by category and location, so browsing here feels closer to
            reading a well-kept flight board than scrolling an ad feed.
          </p>
          <p className="about__text">
            This is the first build in an ongoing project. Right now you can browse, filter, and
            manage destinations end-to-end. Booking, reviews, and personalized itineraries are
            next on the runway.
          </p>
        </div>

        <div className="about__panel">
          <svg className="about__route" viewBox="0 0 260 220" fill="none" aria-hidden="true">
            <path
              d="M20 30 C 90 10, 60 120, 140 100 S 240 190, 240 190"
              stroke="var(--gold)"
              strokeWidth="1.4"
              strokeDasharray="1 7"
              strokeLinecap="round"
            />
            <circle cx="20" cy="30" r="4" fill="var(--coral)" />
            <circle cx="140" cy="100" r="4" fill="var(--teal)" />
            <circle cx="240" cy="190" r="4" fill="var(--gold)" />
          </svg>
          <dl className="about__stats">
            <div>
              <dt>Destinations logged</dt>
              <dd>{destinationCount}</dd>
            </div>
            <div>
              <dt>Countries covered</dt>
              <dd>{countryCount}</dd>
            </div>
            <div>
              <dt>Travel categories</dt>
              <dd>{categoryCount}</dd>
            </div>
            <div>
              <dt>Sponsored placements</dt>
              <dd>0</dd>
            </div>
          </dl>
        </div>
      </div>
    </section>
  );
}

export default About;
