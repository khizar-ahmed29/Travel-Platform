import { useEffect, useState } from "react";

const empty = {
  tripName: "",
  destination: "",
  startDate: "",
  endDate: "",
  travelers: 1,
  description: "",
};

function TripForm({ initialValues = empty, onSubmit, onCancel, submitLabel = "Create trip" }) {
  const [form, setForm] = useState({ ...empty, ...initialValues });
  const [error, setError] = useState("");

  useEffect(() => {
    setForm({ ...empty, ...initialValues });
  }, [initialValues]);

  const change = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (form.endDate < form.startDate) {
      setError("End date cannot be before start date.");
      return;
    }
    try {
      await onSubmit({ ...form, travelers: Number(form.travelers) });
    } catch (err) {
      setError(err.response?.data?.message || "Could not save trip.");
    }
  };

  return (
    <form className="trip-form" onSubmit={submit}>
      {error && <p className="state-msg state-msg--error">{error}</p>}
      <div className="trip-form__grid">
        <label>Trip name<input required value={form.tripName} placeholder="Summer in Istanbul" onChange={(e) => change("tripName", e.target.value)} /></label>
        <label>Destination<input required value={form.destination} placeholder="Istanbul, Türkiye" onChange={(e) => change("destination", e.target.value)} /></label>
        <label>Start date<input required type="date" value={form.startDate} onChange={(e) => change("startDate", e.target.value)} /></label>
        <label>End date<input required type="date" value={form.endDate} onChange={(e) => change("endDate", e.target.value)} /></label>
        <label>Travelers<input required type="number" min="1" max="100" value={form.travelers} onChange={(e) => change("travelers", e.target.value)} /></label>
        <label className="trip-form__wide">Description<textarea rows="3" maxLength="1000" value={form.description} placeholder="What do you want from this trip?" onChange={(e) => change("description", e.target.value)} /></label>
      </div>
      <div className="trip-form__actions">
        <button className="btn btn--primary">{submitLabel}</button>
        {onCancel && <button type="button" className="btn btn--ghost" onClick={onCancel}>Cancel</button>}
      </div>
    </form>
  );
}

export default TripForm;
