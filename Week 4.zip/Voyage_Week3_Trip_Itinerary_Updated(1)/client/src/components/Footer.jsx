function Footer() {
  return (
    <footer className="footer">
      <div className="footer__inner">
        <a href="#top" className="nav__brand nav__brand--footer">
          <span className="nav__brand-mark" aria-hidden="true">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none">
              <path
                d="M2 12.5 21 4l-3 9.5L21 21 2 12.5Zm0 0 9 1"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </span>
          Voyage
        </a>
        <p className="footer__copy">Week 1 build — MERN Travel & Tourism Experience Platform.</p>
        <p className="footer__meta mono">MongoDB · Express · React · Node</p>
      </div>
    </footer>
  );
}

export default Footer;
