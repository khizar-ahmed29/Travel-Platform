function StateMessage({ tone = "info", children }) {
  return <p className={`state-msg state-msg--${tone}`}>{children}</p>;
}

export default StateMessage;
