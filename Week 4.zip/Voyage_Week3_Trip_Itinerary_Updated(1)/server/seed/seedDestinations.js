// Run with: npm run seed
// Populates the database with sample destinations so the frontend has real data.
require("dotenv").config();
const mongoose = require("mongoose");
const connectDB = require("../config/db");
const Destination = require("../models/Destination");

const destinations = [
  {
    name: "Santorini",
    country: "Greece",
    city: "Cyclades",
    description:
      "Whitewashed villages cling to volcanic cliffs above a deep blue caldera, with sunsets over Oia famous the world over.",
    imageUrl: "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=1200&q=80",
    category: "Island",
    featured: true,
    rating: 4.9,
    popularity: 980,
  },
  {
    name: "Kyoto",
    country: "Japan",
    city: "Kansai",
    description:
      "Ancient temples, bamboo groves, and geisha-district streets preserve centuries of Japanese imperial history.",
    imageUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=1200&q=80",
    category: "Cultural",
    featured: true,
    rating: 4.8,
    popularity: 860,
  },
  {
    name: "Banff National Park",
    country: "Canada",
    city: "Alberta",
    description:
      "Turquoise glacial lakes ringed by the Canadian Rockies make this one of the most photographed wilderness areas on Earth.",
    imageUrl: "https://images.unsplash.com/photo-1609825488888-3a766db05542?w=1200&q=80",
    category: "Mountain",
    featured: true,
    rating: 4.9,
    popularity: 910,
  },
  {
    name: "Marrakech",
    country: "Morocco",
    city: "Marrakech-Safi",
    description:
      "A maze of souks, palaces, and riads set against the backdrop of the Atlas Mountains.",
    imageUrl: "https://images.unsplash.com/photo-1553603227-2358aabe821e?w=1200&q=80",
    category: "Cultural",
    featured: false,
    rating: 4.6,
    popularity: 640,
  },
  {
    name: "Bora Bora",
    country: "French Polynesia",
    city: "Society Islands",
    description:
      "Overwater bungalows and lagoons of impossible turquoise make this the archetype of a tropical escape.",
    imageUrl: "https://images.unsplash.com/photo-1544644181-1484b3fdfc62?w=1200&q=80",
    category: "Beach",
    featured: true,
    rating: 5.0,
    popularity: 995,
  },
  {
    name: "Serengeti National Park",
    country: "Tanzania",
    city: "Mara Region",
    description:
      "Home to the Great Migration, where millions of wildebeest and zebra cross endless golden plains.",
    imageUrl: "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=1200&q=80",
    category: "Wildlife",
    featured: false,
    rating: 4.9,
    popularity: 870,
  },
  {
    name: "Machu Picchu",
    country: "Peru",
    city: "Cusco Region",
    description:
      "The lost Incan citadel sits high in the Andes, wrapped in cloud forest and centuries of mystery.",
    imageUrl: "https://images.unsplash.com/photo-1526392060635-9d6019884377?w=1200&q=80",
    category: "Historical",
    featured: true,
    rating: 4.9,
    popularity: 940,
  },
  {
    name: "Queenstown",
    country: "New Zealand",
    city: "Otago",
    description:
      "The adventure capital of the world, with bungee jumping, jet boating, and alpine trails on Lake Wakatipu.",
    imageUrl: "https://images.unsplash.com/photo-1589871973318-9ca1258faa5d?w=1200&q=80",
    category: "Adventure",
    featured: false,
    rating: 4.7,
    popularity: 705,
  },
  {
    name: "Dubai",
    country: "United Arab Emirates",
    city: "Dubai",
    description:
      "Futuristic skyscrapers rise from the desert alongside gold souks and man-made islands.",
    imageUrl: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=1200&q=80",
    category: "City",
    featured: false,
    rating: 4.5,
    popularity: 615,
  },
];

const seed = async () => {
  await connectDB();
  try {
    await Destination.deleteMany();
    await Destination.insertMany(destinations);
    console.log(`Seeded ${destinations.length} destinations successfully.`);
  } catch (error) {
    console.error("Seeding error:", error.message);
  } finally {
    await mongoose.connection.close();
    process.exit(0);
  }
};

seed();
