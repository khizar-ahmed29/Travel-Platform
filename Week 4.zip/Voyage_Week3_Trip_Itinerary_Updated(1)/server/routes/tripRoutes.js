const express = require("express");
const { protect } = require("../middleware/authMiddleware");
const {
  createTrip,
  getTrips,
  getTrip,
  updateTrip,
  deleteTrip,
  addActivity,
  updateActivity,
  deleteActivity,
} = require("../controllers/tripController");

const router = express.Router();

router.use(protect);

router.post("/", createTrip);
router.get("/", getTrips);
router.get("/:tripId", getTrip);
router.put("/:tripId", updateTrip);
router.delete("/:tripId", deleteTrip);

router.post("/:tripId/activities", addActivity);
router.put("/:tripId/activities/:activityId", updateActivity);
router.delete("/:tripId/activities/:activityId", deleteActivity);

module.exports = router;
