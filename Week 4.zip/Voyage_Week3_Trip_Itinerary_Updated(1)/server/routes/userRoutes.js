const express = require("express");
const { protect } = require("../middleware/authMiddleware");
const {
  getDashboard,
  getFavorites,
  addFavorite,
  removeFavorite,
  recordRecentlyViewed,
  updateProfile,
} = require("../controllers/userController");

const router = express.Router();

router.use(protect);

router.get("/dashboard", getDashboard);
router.get("/favorites", getFavorites);
router.post("/favorites/:destinationId", addFavorite);
router.delete("/favorites/:destinationId", removeFavorite);
router.post("/recently-viewed/:destinationId", recordRecentlyViewed);
router.put("/profile", updateProfile);

module.exports = router;
