const dns = require("dns");
// Some ISPs/routers fail to resolve the SRV DNS record that mongodb+srv://
// connection strings rely on. Forcing Node to use public DNS servers works
// around that without needing any OS-level network changes.
dns.setServers(["8.8.8.8", "1.1.1.1"]);

const mongoose = require("mongoose");

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const connectDB = async (retries = 3, delayMs = 2000) => {
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      const conn = await mongoose.connect(process.env.MONGO_URI);
      console.log(`MongoDB Connected: ${conn.connection.host}`);
      return;
    } catch (error) {
      console.error(`MongoDB connection attempt ${attempt} failed: ${error.message}`);
      if (attempt === retries) {
        console.error("All connection attempts failed. Exiting.");
        process.exit(1);
      }
      await wait(delayMs);
    }
  }
};

module.exports = connectDB;
