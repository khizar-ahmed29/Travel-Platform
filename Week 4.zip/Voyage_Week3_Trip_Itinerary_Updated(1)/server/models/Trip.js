const mongoose = require("mongoose");

const activitySchema = new mongoose.Schema(
  {
    title: { type: String, required: [true, "Activity title is required"], trim: true, maxlength: 120 },
    location: { type: String, trim: true, maxlength: 180, default: "" },
    date: { type: Date, required: [true, "Activity date is required"] },
    time: { type: String, trim: true, default: "" },
    category: {
      type: String,
      trim: true,
      default: "Other",
      enum: ["Sightseeing", "Food", "Adventure", "Culture", "Shopping", "Transport", "Relaxation", "Other"],
    },
    description: { type: String, trim: true, maxlength: 600, default: "" },
  },
  { _id: true }
);

const itineraryDaySchema = new mongoose.Schema(
  {
    dayNumber: { type: Number, required: true, min: 1 },
    date: { type: Date, required: true },
    activities: { type: [activitySchema], default: [] },
  },
  { _id: false }
);

const tripSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },
    tripName: {
      type: String,
      required: [true, "Trip name is required"],
      trim: true,
      maxlength: 120,
    },
    destination: {
      type: String,
      required: [true, "Destination is required"],
      trim: true,
      maxlength: 160,
    },
    startDate: { type: Date, required: [true, "Start date is required"] },
    endDate: { type: Date, required: [true, "End date is required"] },
    travelers: { type: Number, required: true, min: 1, max: 100, default: 1 },
    description: { type: String, trim: true, maxlength: 1000, default: "" },
    status: {
      type: String,
      enum: ["upcoming", "ongoing", "completed", "cancelled"],
      default: "upcoming",
    },
    itinerary: { type: [itineraryDaySchema], default: [] },
  },
  { timestamps: true }
);

tripSchema.index({ user: 1, startDate: 1 });

module.exports = mongoose.model("Trip", tripSchema);
