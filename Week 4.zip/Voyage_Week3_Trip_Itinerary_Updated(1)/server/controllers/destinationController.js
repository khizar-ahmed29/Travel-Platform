const Destination = require("../models/Destination");

// @desc    Get all destinations
//          Supports ?category=, ?featured=true, ?search=, ?sort=
// @route   GET /api/destinations
const getDestinations = async (req, res) => {
  try {
    const filter = {};
    if (req.query.category) filter.category = req.query.category;
    if (req.query.featured) filter.featured = req.query.featured === "true";

    if (req.query.search) {
      const term = req.query.search.trim();
      const regex = new RegExp(term, "i");
      filter.$or = [{ name: regex }, { country: regex }, { city: regex }];
    }

    const sortOptions = {
      rating: { rating: -1 },
      popularity: { popularity: -1 },
      newest: { createdAt: -1 },
      name: { name: 1 },
    };
    const sort = sortOptions[req.query.sort] || { createdAt: -1 };

    const destinations = await Destination.find(filter).sort(sort);
    res.status(200).json({ success: true, count: destinations.length, data: destinations });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error while fetching destinations", error: error.message });
  }
};

// @desc    Get destinations belonging to a single category
// @route   GET /api/destinations/category/:category
const getDestinationsByCategory = async (req, res) => {
  try {
    const destinations = await Destination.find({ category: req.params.category }).sort({ createdAt: -1 });
    res.status(200).json({ success: true, count: destinations.length, data: destinations });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error while filtering destinations", error: error.message });
  }
};

// @desc    Get a single destination by id
// @route   GET /api/destinations/:id
const getDestinationById = async (req, res) => {
  try {
    const destination = await Destination.findById(req.params.id);
    if (!destination) {
      return res.status(404).json({ success: false, message: "Destination not found" });
    }
    res.status(200).json({ success: true, data: destination });
  } catch (error) {
    if (error.kind === "ObjectId") {
      return res.status(400).json({ success: false, message: "Invalid destination id" });
    }
    res.status(500).json({ success: false, message: "Server error while fetching destination", error: error.message });
  }
};

// @desc    Create a new destination
// @route   POST /api/destinations
const createDestination = async (req, res) => {
  try {
    const destination = await Destination.create(req.body);
    res.status(201).json({ success: true, data: destination });
  } catch (error) {
    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((val) => val.message);
      return res.status(400).json({ success: false, message: messages.join(", ") });
    }
    res.status(500).json({ success: false, message: "Server error while creating destination", error: error.message });
  }
};

// @desc    Update an existing destination
// @route   PUT /api/destinations/:id
const updateDestination = async (req, res) => {
  try {
    const destination = await Destination.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!destination) {
      return res.status(404).json({ success: false, message: "Destination not found" });
    }
    res.status(200).json({ success: true, data: destination });
  } catch (error) {
    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((val) => val.message);
      return res.status(400).json({ success: false, message: messages.join(", ") });
    }
    res.status(500).json({ success: false, message: "Server error while updating destination", error: error.message });
  }
};

// @desc    Delete a destination
// @route   DELETE /api/destinations/:id
const deleteDestination = async (req, res) => {
  try {
    const destination = await Destination.findByIdAndDelete(req.params.id);
    if (!destination) {
      return res.status(404).json({ success: false, message: "Destination not found" });
    }
    res.status(200).json({ success: true, message: "Destination deleted", data: destination });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error while deleting destination", error: error.message });
  }
};

module.exports = {
  getDestinations,
  getDestinationsByCategory,
  getDestinationById,
  createDestination,
  updateDestination,
  deleteDestination,
};
