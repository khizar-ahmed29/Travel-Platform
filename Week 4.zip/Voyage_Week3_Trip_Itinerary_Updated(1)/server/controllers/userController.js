const User = require("../models/User");
const Destination = require("../models/Destination");

const getDashboard = async (req, res) => {
  try {
    const user = await User.findById(req.userId)
      .populate("favorites")
      .populate("recentlyViewed.destination");

    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    const recommendations = await Destination.find({ featured: true }).sort({
      rating: -1,
      popularity: -1,
    }).limit(6);

    res.json({
      success: true,
      data: {
        user: {
          _id: user._id,
          name: user.name,
          email: user.email,
          profileImage: user.profileImage || "",
          bio: user.bio || "",
        },
        favorites: user.favorites,
        recentlyViewed: user.recentlyViewed
          .filter((item) => item.destination)
          .sort((a, b) => new Date(b.viewedAt) - new Date(a.viewedAt))
          .slice(0, 6),
        recommendations,
        statistics: {
          favorites: user.favorites.length,
          recentlyViewed: user.recentlyViewed.length,
          memberSince: user.createdAt,
        },
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server error while loading dashboard",
      error: error.message,
    });
  }
};

const getFavorites = async (req, res) => {
  try {
    const user = await User.findById(req.userId).populate("favorites");
    res.json({
      success: true,
      count: user.favorites.length,
      data: user.favorites,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server error while loading favorites",
      error: error.message,
    });
  }
};

const addFavorite = async (req, res) => {
  try {
    const destination = await Destination.findById(req.params.destinationId);
    if (!destination) {
      return res.status(404).json({ success: false, message: "Destination not found" });
    }

    const user = await User.findById(req.userId);
    const exists = user.favorites.some((id) => id.toString() === destination._id.toString());

    if (!exists) user.favorites.push(destination._id);
    await user.save();

    res.json({
      success: true,
      message: exists ? "Destination is already saved" : "Destination saved",
      favorite: !exists,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server error while saving favorite",
      error: error.message,
    });
  }
};

const removeFavorite = async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    user.favorites = user.favorites.filter(
      (id) => id.toString() !== req.params.destinationId
    );
    await user.save();

    res.json({ success: true, message: "Destination removed from favorites", favorite: false });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server error while removing favorite",
      error: error.message,
    });
  }
};

const recordRecentlyViewed = async (req, res) => {
  try {
    const destination = await Destination.findById(req.params.destinationId);
    if (!destination) {
      return res.status(404).json({ success: false, message: "Destination not found" });
    }

    const user = await User.findById(req.userId);

    user.recentlyViewed = user.recentlyViewed.filter(
      (item) => item.destination.toString() !== destination._id.toString()
    );
    user.recentlyViewed.unshift({
      destination: destination._id,
      viewedAt: new Date(),
    });
    user.recentlyViewed = user.recentlyViewed.slice(0, 12);

    await user.save();

    res.json({ success: true, message: "Recently viewed updated" });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server error while updating recently viewed",
      error: error.message,
    });
  }
};

const updateProfile = async (req, res) => {
  try {
    const { name, profileImage, bio } = req.body;
    const user = await User.findById(req.userId);

    if (name !== undefined) user.name = name.trim();
    if (profileImage !== undefined) user.profileImage = profileImage.trim();
    if (bio !== undefined) user.bio = bio.trim();

    await user.save();

    res.json({
      success: true,
      message: "Profile updated",
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        profileImage: user.profileImage || "",
        bio: user.bio || "",
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server error while updating profile",
      error: error.message,
    });
  }
};

module.exports = {
  getDashboard,
  getFavorites,
  addFavorite,
  removeFavorite,
  recordRecentlyViewed,
  updateProfile,
};
