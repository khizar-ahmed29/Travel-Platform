const mongoose = require("mongoose");
const Trip = require("../models/Trip");

const normalizeDate = (value) => {
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
};

const buildItinerary = (startDate, endDate) => {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const days = [];
  const cursor = new Date(start);
  let dayNumber = 1;

  while (cursor <= end && dayNumber <= 366) {
    days.push({
      dayNumber,
      date: new Date(cursor),
      activities: [],
    });
    cursor.setDate(cursor.getDate() + 1);
    dayNumber += 1;
  }
  return days;
};

const refreshStatus = (trip) => {
  if (trip.status === "cancelled") return trip.status;
  const now = new Date();
  const start = new Date(trip.startDate);
  const end = new Date(trip.endDate);
  end.setHours(23, 59, 59, 999);

  if (now < start) return "upcoming";
  if (now <= end) return "ongoing";
  return "completed";
};

const validateDates = (startDate, endDate) => {
  const start = normalizeDate(startDate);
  const end = normalizeDate(endDate);
  if (!start || !end) return { error: "Please provide valid start and end dates." };
  if (end < start) return { error: "End date cannot be before start date." };
  return { start, end };
};

const getUserTrip = async (userId, tripId) => {
  if (!mongoose.Types.ObjectId.isValid(tripId)) return null;
  return Trip.findOne({ _id: tripId, user: userId });
};

const createTrip = async (req, res) => {
  try {
    const { tripName, destination, startDate, endDate, travelers = 1, description = "", status } = req.body;
    if (!tripName || !destination || !startDate || !endDate) {
      return res.status(400).json({ success: false, message: "Trip name, destination, start date and end date are required." });
    }

    const dates = validateDates(startDate, endDate);
    if (dates.error) return res.status(400).json({ success: false, message: dates.error });

    const trip = await Trip.create({
      user: req.userId,
      tripName,
      destination,
      startDate: dates.start,
      endDate: dates.end,
      travelers: Number(travelers) || 1,
      description,
      status: status === "cancelled" ? "cancelled" : "upcoming",
      itinerary: buildItinerary(dates.start, dates.end),
    });

    res.status(201).json({ success: true, message: "Trip created successfully", data: trip });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error while creating trip", error: error.message });
  }
};

const getTrips = async (req, res) => {
  try {
    const trips = await Trip.find({ user: req.userId }).sort({ startDate: 1 });
    const changed = [];

    for (const trip of trips) {
      const next = refreshStatus(trip);
      if (trip.status !== next) {
        trip.status = next;
        changed.push(trip.save());
      }
    }
    if (changed.length) await Promise.all(changed);

    res.json({ success: true, count: trips.length, data: trips });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error while loading trips", error: error.message });
  }
};

const getTrip = async (req, res) => {
  try {
    const trip = await getUserTrip(req.userId, req.params.tripId);
    if (!trip) return res.status(404).json({ success: false, message: "Trip not found" });

    const next = refreshStatus(trip);
    if (trip.status !== next) {
      trip.status = next;
      await trip.save();
    }

    res.json({ success: true, data: trip });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error while loading trip", error: error.message });
  }
};

const updateTrip = async (req, res) => {
  try {
    const trip = await getUserTrip(req.userId, req.params.tripId);
    if (!trip) return res.status(404).json({ success: false, message: "Trip not found" });

    const nextStart = req.body.startDate ?? trip.startDate;
    const nextEnd = req.body.endDate ?? trip.endDate;
    const dates = validateDates(nextStart, nextEnd);
    if (dates.error) return res.status(400).json({ success: false, message: dates.error });

    const dateChanged =
      new Date(trip.startDate).getTime() !== dates.start.getTime() ||
      new Date(trip.endDate).getTime() !== dates.end.getTime();

    if (req.body.tripName !== undefined) trip.tripName = req.body.tripName;
    if (req.body.destination !== undefined) trip.destination = req.body.destination;
    if (req.body.travelers !== undefined) trip.travelers = Number(req.body.travelers) || 1;
    if (req.body.description !== undefined) trip.description = req.body.description;
    if (req.body.status !== undefined && ["upcoming", "ongoing", "completed", "cancelled"].includes(req.body.status)) {
      trip.status = req.body.status;
    }

    trip.startDate = dates.start;
    trip.endDate = dates.end;

    if (dateChanged) {
      const oldActivities = trip.itinerary.flatMap((day) => day.activities);
      const newItinerary = buildItinerary(dates.start, dates.end);

      for (const activity of oldActivities) {
        const activityDate = new Date(activity.date);
        const matchingDay = newItinerary.find((day) => {
          const a = new Date(day.date);
          return a.toDateString() === activityDate.toDateString();
        });
        if (matchingDay) matchingDay.activities.push(activity);
      }
      trip.itinerary = newItinerary;
    }

    await trip.save();
    res.json({ success: true, message: "Trip updated successfully", data: trip });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error while updating trip", error: error.message });
  }
};

const deleteTrip = async (req, res) => {
  try {
    const trip = await getUserTrip(req.userId, req.params.tripId);
    if (!trip) return res.status(404).json({ success: false, message: "Trip not found" });

    await trip.deleteOne();
    res.json({ success: true, message: "Trip deleted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error while deleting trip", error: error.message });
  }
};

const findDay = (trip, dayNumber) => trip.itinerary.find((day) => Number(day.dayNumber) === Number(dayNumber));

const addActivity = async (req, res) => {
  try {
    const trip = await getUserTrip(req.userId, req.params.tripId);
    if (!trip) return res.status(404).json({ success: false, message: "Trip not found" });

    const { dayNumber, title, location = "", date, time = "", category = "Other", description = "" } = req.body;
    if (!dayNumber || !title || !date) {
      return res.status(400).json({ success: false, message: "Day number, activity title and date are required." });
    }

    const day = findDay(trip, dayNumber);
    if (!day) return res.status(400).json({ success: false, message: "That itinerary day does not exist." });

    const activityDate = normalizeDate(date);
    if (!activityDate) return res.status(400).json({ success: false, message: "Invalid activity date." });

    const start = new Date(trip.startDate);
    const end = new Date(trip.endDate);
    if (activityDate < start || activityDate > end) {
      return res.status(400).json({ success: false, message: "Activity date must fall within the trip dates." });
    }

    day.activities.push({ title, location, date: activityDate, time, category, description });
    await trip.save();

    res.status(201).json({ success: true, message: "Activity added successfully", data: trip });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error while adding activity", error: error.message });
  }
};

const locateActivity = (trip, activityId) => {
  for (const day of trip.itinerary) {
    const activity = day.activities.id(activityId);
    if (activity) return { day, activity };
  }
  return null;
};

const updateActivity = async (req, res) => {
  try {
    const trip = await getUserTrip(req.userId, req.params.tripId);
    if (!trip) return res.status(404).json({ success: false, message: "Trip not found" });

    if (!mongoose.Types.ObjectId.isValid(req.params.activityId)) {
      return res.status(400).json({ success: false, message: "Invalid activity ID." });
    }

    const found = locateActivity(trip, req.params.activityId);
    if (!found) return res.status(404).json({ success: false, message: "Activity not found" });

    const fields = ["title", "location", "date", "time", "category", "description"];
    for (const field of fields) {
      if (req.body[field] !== undefined) found.activity[field] = field === "date" ? normalizeDate(req.body[field]) : req.body[field];
    }
    if (req.body.dayNumber !== undefined && Number(req.body.dayNumber) !== found.day.dayNumber) {
      const newDay = findDay(trip, req.body.dayNumber);
      if (!newDay) return res.status(400).json({ success: false, message: "Target itinerary day does not exist." });
      found.day.activities.pull(found.activity._id);
      newDay.activities.push(found.activity);
    }

    await trip.save();
    res.json({ success: true, message: "Activity updated successfully", data: trip });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error while updating activity", error: error.message });
  }
};

const deleteActivity = async (req, res) => {
  try {
    const trip = await getUserTrip(req.userId, req.params.tripId);
    if (!trip) return res.status(404).json({ success: false, message: "Trip not found" });

    if (!mongoose.Types.ObjectId.isValid(req.params.activityId)) {
      return res.status(400).json({ success: false, message: "Invalid activity ID." });
    }

    const found = locateActivity(trip, req.params.activityId);
    if (!found) return res.status(404).json({ success: false, message: "Activity not found" });

    found.day.activities.pull(found.activity._id);
    await trip.save();

    res.json({ success: true, message: "Activity deleted successfully", data: trip });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error while deleting activity", error: error.message });
  }
};

module.exports = {
  createTrip,
  getTrips,
  getTrip,
  updateTrip,
  deleteTrip,
  addActivity,
  updateActivity,
  deleteActivity,
};
