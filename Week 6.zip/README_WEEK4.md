# Voyage Week 4 — Travel Service & Booking Management

This update adds a complete travel service and booking flow to the existing Voyage MERN project.

## Features
- Travel service MongoDB model with name, category, location, description, image, price, rating, availability and features.
- Public service browsing and category filtering.
- Service details page with Book Now flow.
- Authenticated booking form with date, people and special request.
- Automatic total-price calculation.
- Booking confirmation with Booking ID and Pending status.
- Authenticated booking history with cancellation.
- Booking model linked to User and Service.
- REST APIs for service CRUD and user bookings.
- Existing JWT authentication and MongoDB setup reused.
- Responsive UI.

## New frontend routes
- `/services`
- `/services/:id`
- `/services/:id/book` (protected)
- `/bookings` (protected)
- `/bookings/confirmation/:id` (protected)

## New API routes
Services:
- GET `/api/services`
- GET `/api/services/:id`
- POST `/api/services` (protected)
- PUT `/api/services/:id` (protected)
- DELETE `/api/services/:id` (protected)
- Filter: `/api/services?category=Hotels`

Bookings:
- POST `/api/bookings` (protected)
- GET `/api/bookings` (protected)
- GET `/api/bookings/:id` (protected)
- PUT `/api/bookings/:id` (protected)
- PATCH `/api/bookings/:id/cancel` (protected)

## Seed sample services
From `server` run:
```bash
npm install
npm run seed:services
npm run dev
```
The seed script inserts six sample travel services. It clears existing Service documents before inserting the samples.

## Client
From `client` run:
```bash
npm install
npm run dev
```

No new environment variables are required. Use the existing `server/.env` and `client/.env` from the previous weeks.
