const mongoose = require("mongoose");
const Review = require("../models/Review");

const targetFilter = (type, id) => ({ [type]: id });
const validTarget = (type) => type === "destination" || type === "service";

const getReviews = async (req, res) => {
  try {
    const { type, id, rating, sort = "newest" } = req.query;
    if (!validTarget(type) || !mongoose.isValidObjectId(id)) return res.status(400).json({ success:false, message:"Valid type and id are required." });
    const filter = { ...targetFilter(type, id) };
    if (rating) filter.rating = Number(rating);
    let query = Review.find(filter).populate("user", "name profileImage");
    if (sort === "helpful") query = query.sort({ helpfulCount: -1, createdAt: -1 });
    else if (sort === "highest") query = query.sort({ rating: -1, createdAt: -1 });
    else if (sort === "lowest") query = query.sort({ rating: 1, createdAt: -1 });
    else query = query.sort({ createdAt: -1 });
    const reviews = await query;
    const stats = await Review.aggregate([
      { $match: filter },
      { $group: { _id: null, averageRating: { $avg: "$rating" }, totalReviews: { $sum: 1 }, ratings: { $push: "$rating" } } }
    ]);
    const s = stats[0] || { averageRating: 0, totalReviews: 0, ratings: [] };
    const distribution = [5,4,3,2,1].reduce((obj, n) => { obj[n] = s.ratings.filter(r => r === n).length; return obj; }, {});
    res.json({ success:true, data: reviews, stats:{ averageRating:Number(s.averageRating.toFixed(1)), totalReviews:s.totalReviews, distribution } });
  } catch (error) { res.status(500).json({ success:false, message:error.message }); }
};

const getReviewById = async (req,res) => {
  try { const review = await Review.findById(req.params.id).populate("user", "name profileImage"); if(!review) return res.status(404).json({success:false,message:"Review not found."}); res.json({success:true,data:review}); }
  catch(e){ res.status(400).json({success:false,message:"Invalid review ID."}); }
};

const createReview = async (req,res) => {
  try {
    const { type, targetId, rating, reviewText, image = "" } = req.body;
    if (!validTarget(type) || !mongoose.isValidObjectId(targetId)) return res.status(400).json({success:false,message:"Valid review target is required."});
    if (!rating || Number(rating) < 1 || Number(rating) > 5) return res.status(400).json({success:false,message:"Rating must be between 1 and 5."});
    if (!reviewText || reviewText.trim().length < 3) return res.status(400).json({success:false,message:"Review text is required."});
    const existing = await Review.findOne({ user:req.userId, [type]:targetId });
    if (existing) return res.status(409).json({success:false,message:"You have already reviewed this item. You can edit your review."});
    const review = await Review.create({ user:req.userId, [type]:targetId, rating:Number(rating), reviewText:reviewText.trim(), image });
    await review.populate("user", "name profileImage");
    res.status(201).json({success:true,data:review,message:"Review submitted successfully."});
  } catch(e){ res.status(400).json({success:false,message:e.message}); }
};

const updateReview = async (req,res) => {
  try {
    const review = await Review.findOne({_id:req.params.id,user:req.userId});
    if(!review) return res.status(404).json({success:false,message:"Review not found or not owned by you."});
    const { rating, reviewText, image } = req.body;
    if (rating !== undefined && (Number(rating)<1 || Number(rating)>5)) return res.status(400).json({success:false,message:"Rating must be between 1 and 5."});
    if (reviewText !== undefined && reviewText.trim().length < 3) return res.status(400).json({success:false,message:"Review text is required."});
    if(rating !== undefined) review.rating=Number(rating); if(reviewText!==undefined) review.reviewText=reviewText.trim(); if(image!==undefined) review.image=image;
    await review.save(); await review.populate("user", "name profileImage"); res.json({success:true,data:review,message:"Review updated successfully."});
  } catch(e){ res.status(400).json({success:false,message:e.message}); }
};

const deleteReview = async (req,res) => { try { const r=await Review.findOneAndDelete({_id:req.params.id,user:req.userId}); if(!r) return res.status(404).json({success:false,message:"Review not found or not owned by you."}); res.json({success:true,message:"Review deleted successfully."}); } catch(e){res.status(400).json({success:false,message:"Invalid review ID."});} };
const markHelpful = async (req,res) => { try { const r=await Review.findByIdAndUpdate(req.params.id,{$inc:{helpfulCount:1}},{new:true}); if(!r)return res.status(404).json({success:false,message:"Review not found."}); res.json({success:true,data:{helpfulCount:r.helpfulCount}}); } catch(e){res.status(400).json({success:false,message:"Invalid review ID."});} };

module.exports = {getReviews,getReviewById,createReview,updateReview,deleteReview,markHelpful};
