const Booking = require("../models/Booking");
const Service = require("../models/Service");

const createBooking = async (req, res) => {
  try {
    const { serviceId, bookingDate, numberOfPeople, specialRequest = "" } = req.body;
    if (!serviceId || !bookingDate || !numberOfPeople) {
      return res.status(400).json({ success: false, message: "Service, booking date and number of people are required" });
    }
    const service = await Service.findById(serviceId);
    if (!service) return res.status(404).json({ success: false, message: "Service not found" });
    if (!service.availability) return res.status(400).json({ success: false, message: "This service is currently unavailable" });
    const people = Number(numberOfPeople);
    if (!Number.isInteger(people) || people < 1) return res.status(400).json({ success: false, message: "Number of people must be at least 1" });
    const date = new Date(bookingDate);
    if (Number.isNaN(date.getTime())) return res.status(400).json({ success: false, message: "Invalid booking date" });
    const booking = await Booking.create({ user: req.userId, service: service._id, bookingDate: date, numberOfPeople: people, totalPrice: service.price * people, specialRequest });
    const populated = await booking.populate("service", "serviceName category location image price");
    res.status(201).json({ success: true, message: "Booking created successfully", data: populated });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not create booking", error: error.message });
  }
};

const getUserBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ user: req.userId }).populate("service").sort({ bookingDate: -1, createdAt: -1 });
    res.json({ success: true, count: bookings.length, data: bookings });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not load bookings", error: error.message });
  }
};

const getBooking = async (req, res) => {
  try {
    const booking = await Booking.findOne({ _id: req.params.id, user: req.userId }).populate("service");
    if (!booking) return res.status(404).json({ success: false, message: "Booking not found" });
    res.json({ success: true, data: booking });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not load booking", error: error.message });
  }
};

const updateBooking = async (req, res) => {
  try {
    const booking = await Booking.findOne({ _id: req.params.id, user: req.userId });
    if (!booking) return res.status(404).json({ success: false, message: "Booking not found" });
    if (booking.bookingStatus === "Cancelled" || booking.bookingStatus === "Completed") return res.status(400).json({ success: false, message: "This booking can no longer be changed" });
    const service = await Service.findById(booking.service);
    if (req.body.bookingDate !== undefined) booking.bookingDate = new Date(req.body.bookingDate);
    if (req.body.numberOfPeople !== undefined) {
      const people = Number(req.body.numberOfPeople);
      if (!Number.isInteger(people) || people < 1) return res.status(400).json({ success: false, message: "Invalid number of people" });
      booking.numberOfPeople = people;
      booking.totalPrice = service.price * people;
    }
    if (req.body.specialRequest !== undefined) booking.specialRequest = req.body.specialRequest;
    if (req.body.bookingStatus && ["Pending", "Confirmed", "Cancelled", "Completed"].includes(req.body.bookingStatus)) booking.bookingStatus = req.body.bookingStatus;
    await booking.save();
    await booking.populate("service");
    res.json({ success: true, message: "Booking updated", data: booking });
  } catch (error) {
    res.status(400).json({ success: false, message: "Could not update booking", error: error.message });
  }
};

const cancelBooking = async (req, res) => {
  try {
    const booking = await Booking.findOne({ _id: req.params.id, user: req.userId });
    if (!booking) return res.status(404).json({ success: false, message: "Booking not found" });
    if (booking.bookingStatus === "Completed") return res.status(400).json({ success: false, message: "Completed bookings cannot be cancelled" });
    booking.bookingStatus = "Cancelled";
    await booking.save();
    res.json({ success: true, message: "Booking cancelled", data: booking });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not cancel booking", error: error.message });
  }
};

module.exports = { createBooking, getUserBookings, getBooking, updateBooking, cancelBooking };
