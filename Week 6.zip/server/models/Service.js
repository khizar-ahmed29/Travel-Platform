const mongoose = require("mongoose");

const serviceSchema = new mongoose.Schema({
  serviceName: { type: String, required: true, trim: true, maxlength: 120 },
  category: { type: String, required: true, trim: true },
  location: { type: String, required: true, trim: true },
  description: { type: String, required: true, trim: true },
  image: { type: String, default: "" },
  price: { type: Number, required: true, min: 0 },
  rating: { type: Number, default: 4.5, min: 0, max: 5 },
  availability: { type: Boolean, default: true },
  features: [{ type: String, trim: true }]
}, { timestamps: true });

module.exports = mongoose.model("Service", serviceSchema);
