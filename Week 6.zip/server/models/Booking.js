const mongoose = require("mongoose");

const bookingSchema = new mongoose.Schema({
  bookingId: { type: String, unique: true, index: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  service: { type: mongoose.Schema.Types.ObjectId, ref: "Service", required: true },
  bookingDate: { type: Date, required: true },
  numberOfPeople: { type: Number, required: true, min: 1 },
  totalPrice: { type: Number, required: true, min: 0 },
  specialRequest: { type: String, default: "", maxlength: 1000 },
  bookingStatus: {
    type: String,
    enum: ["Pending", "Confirmed", "Cancelled", "Completed"],
    default: "Pending"
  }
}, { timestamps: true });

bookingSchema.pre("validate", function(next) {
  if (!this.bookingId) {
    this.bookingId = `VOY-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
  }
  next();
});

module.exports = mongoose.model("Booking", bookingSchema);
