import { useEffect, useState } from "react";
import { createReview, deleteReview, getReviews, markReviewHelpful, updateReview } from "../services/api.js";
import { useAuth } from "../context/AuthContext.jsx";

const Stars = ({ value, onChange }) => <div className="review-stars" aria-label="Rating">{[1,2,3,4,5].map(n => <button key={n} type="button" className={n <= value ? "is-active" : ""} onClick={() => onChange?.(n)} disabled={!onChange}>★</button>)}</div>;

function ReviewSection({ type, targetId }) {
  const { user } = useAuth();
  const [reviews,setReviews]=useState([]), [stats,setStats]=useState({averageRating:0,totalReviews:0,distribution:{}}), [rating,setRating]=useState(5), [text,setText]=useState(""), [image,setImage]=useState(""), [filter,setFilter]=useState("newest"), [loading,setLoading]=useState(true), [message,setMessage]=useState(""), [editing,setEditing]=useState(null);
  const load=async()=>{setLoading(true); try{const r=await getReviews(type,targetId,{sort:filter});setReviews(r.data||[]);setStats(r.stats||stats);}catch(e){setMessage(e.response?.data?.message||"Could not load reviews.")}finally{setLoading(false)}};
  useEffect(()=>{load()},[type,targetId,filter]);
  const submit=async e=>{e.preventDefault();setMessage("");if(!text.trim())return setMessage("Review text is required.");try{if(editing) await updateReview(editing,{rating,reviewText:text,image});else await createReview({type,targetId,rating,reviewText:text,image});setText("");setImage("");setRating(5);setEditing(null);await load();}catch(e){setMessage(e.response?.data?.message||"Unable to save review.")}};
  const edit=r=>{setEditing(r._id);setRating(r.rating);setText(r.reviewText);setImage(r.image||"");window.scrollTo({top:document.body.scrollHeight,behavior:"smooth"})};
  const remove=async id=>{if(!confirm("Delete this review?"))return;try{await deleteReview(id);await load()}catch(e){setMessage(e.response?.data?.message||"Unable to delete review.")}};
  return <section className="reviews-section">
    <div className="reviews-head"><div><p className="eyebrow">Traveler feedback</p><h2>Reviews & Ratings</h2></div><div className="rating-summary"><strong>{stats.averageRating.toFixed(1)}</strong><span>★</span><small>{stats.totalReviews} reviews</small></div></div>
    <div className="rating-distribution">{[5,4,3,2,1].map(n=><div key={n}><span>{n} ★</span><div className="rating-bar"><i style={{width:`${stats.totalReviews?(stats.distribution?.[n]||0)/stats.totalReviews*100:0}%`}}/></div><small>{stats.distribution?.[n]||0}</small></div>)}</div>
    {user && <form className="review-form" onSubmit={submit}><h3>{editing?"Edit your review":"Share your experience"}</h3><Stars value={rating} onChange={setRating}/><textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Write your review..." maxLength={1000}/><input value={image} onChange={e=>setImage(e.target.value)} placeholder="Image URL (optional)"/><div className="review-form__actions"><button className="btn btn--primary" type="submit">{editing?"Update review":"Submit review"}</button>{editing&&<button className="btn btn--ghost" type="button" onClick={()=>{setEditing(null);setText("");setImage("")}}>Cancel</button>}</div>{message&&<p className="review-message">{message}</p>}</form>}
    {!user && <p className="review-login">Log in to share your review.</p>}
    <div className="reviews-toolbar"><h3>Traveler reviews</h3><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="newest">Newest</option><option value="helpful">Most helpful</option><option value="highest">Highest rated</option><option value="lowest">Lowest rated</option></select></div>
    {loading?<p>Loading reviews…</p>:reviews.length===0?<p>No reviews yet. Be the first to share your experience.</p>:<div className="review-list">{reviews.map(r=><article className="review-card" key={r._id}><div className="review-card__top"><div className="review-author">{r.user?.profileImage?<img src={r.user.profileImage} alt=""/>:<span>{r.user?.name?.[0]||"T"}</span>}<div><strong>{r.user?.name||"Traveler"}</strong><small>{new Date(r.createdAt).toLocaleDateString()}</small></div></div><Stars value={r.rating}/></div><p>{r.reviewText}</p>{r.image&&<img className="review-image" src={r.image} alt="Review"/>}<div className="review-card__actions"><button type="button" onClick={async()=>{await markReviewHelpful(r._id);load()}}>Helpful ({r.helpfulCount||0})</button>{user?._id===r.user?._id&&<><button type="button" onClick={()=>edit(r)}>Edit</button><button type="button" onClick={()=>remove(r._id)}>Delete</button></>}</div></article>)}</div>}
  </section>;
}
export default ReviewSection;
