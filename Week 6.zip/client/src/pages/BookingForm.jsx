import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import StateMessage from "../components/StateMessage.jsx";
import { createBooking, getService } from "../services/api.js";

function BookingForm() {
  const { id } = useParams(); const navigate = useNavigate();
  const [service,setService]=useState(null); const [error,setError]=useState(""); const [loading,setLoading]=useState(false);
  const [form,setForm]=useState({bookingDate:"",numberOfPeople:1,specialRequest:""});
  useEffect(()=>{getService(id).then(r=>setService(r.data)).catch(e=>setError(e.response?.data?.message||"Could not load service."));},[id]);
  const total=useMemo(()=>Number(service?.price||0)*Number(form.numberOfPeople||0),[service,form.numberOfPeople]);
  const submit=async e=>{e.preventDefault();setError("");setLoading(true);try{const r=await createBooking({serviceId:id,...form});navigate(`/bookings/confirmation/${r.data._id}`,{state:{booking:r.data}});}catch(err){setError(err.response?.data?.message||"Could not create booking.");}finally{setLoading(false)}};
  if(!service&&!error)return <><Navbar/><main className="section"><StateMessage tone="info">Loading booking form…</StateMessage></main></>;
  if(error&&!service)return <><Navbar/><main className="section"><StateMessage tone="error">{error}</StateMessage></main></>;
  return <><Navbar/><main className="booking-shell"><form className="booking-card" onSubmit={submit}><div><p className="eyebrow"><span className="eyebrow__code">BOOK NOW</span> Reserve your experience</p><h1>Book {service.serviceName}</h1><p className="section__sub">{service.location} · PKR {Number(service.price).toLocaleString()} per person</p></div>{error&&<StateMessage tone="error">{error}</StateMessage>}<label className="form-field">Booking date<input type="date" required min={new Date().toISOString().split("T")[0]} value={form.bookingDate} onChange={e=>setForm({...form,bookingDate:e.target.value})}/></label><label className="form-field">Number of people<input type="number" required min="1" value={form.numberOfPeople} onChange={e=>setForm({...form,numberOfPeople:e.target.value})}/></label><label className="form-field">Special request<textarea rows="4" placeholder="Anything we should know?" value={form.specialRequest} onChange={e=>setForm({...form,specialRequest:e.target.value})}/></label><div className="booking-summary"><span>Total price</span><strong>PKR {total.toLocaleString()}</strong></div><button className="btn btn--primary btn--large" disabled={loading}>{loading?"Processing…":"Confirm booking"}</button></form></main><Footer/></>;
}
export default BookingForm;
