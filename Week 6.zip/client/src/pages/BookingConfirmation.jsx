import { Link, useLocation } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";

function BookingConfirmation(){
 const {state}=useLocation(); const b=state?.booking;
 return <><Navbar/><main className="confirmation-shell"><div className="confirmation-card"><div className="confirmation-icon">✓</div><p className="eyebrow"><span className="eyebrow__code">CONFIRMED</span> Voyage booking</p><h1>Booking request received.</h1>{b?<><p>Your request for <strong>{b.service?.serviceName}</strong> has been saved successfully.</p><div className="confirmation-grid"><span>Booking ID<strong>{b.bookingId}</strong></span><span>Date<strong>{new Date(b.bookingDate).toLocaleDateString()}</strong></span><span>People<strong>{b.numberOfPeople}</strong></span><span>Total<strong>PKR {Number(b.totalPrice).toLocaleString()}</strong></span><span>Status<strong>{b.bookingStatus}</strong></span></div></>:<p>Your booking was saved. Open Booking History to see its details.</p>}<div className="confirmation-actions"><Link className="btn btn--primary" to="/bookings">View bookings</Link><Link className="btn btn--ghost" to="/services">Explore services</Link></div></div></main><Footer/></>;
}
export default BookingConfirmation;
