import { useEffect, useMemo, useState } from "react";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import StateMessage from "../components/StateMessage.jsx";
import { cancelBooking, getBookings } from "../services/api.js";

function Bookings(){
 const [bookings,setBookings]=useState([]); const [error,setError]=useState("");
 const load=async()=>{try{const r=await getBookings();setBookings(r.data)}catch(e){setError(e.response?.data?.message||"Could not load bookings.")}};
 useEffect(()=>{load()},[]);
 const upcoming=useMemo(()=>bookings.filter(b=>!['Cancelled','Completed'].includes(b.bookingStatus)),[bookings]);
 const cancel=async id=>{if(!confirm("Cancel this booking?"))return;try{await cancelBooking(id);load()}catch(e){setError(e.response?.data?.message||"Could not cancel booking.")}};
 return <><Navbar/><main><section className="trip-hero"><div><p className="eyebrow eyebrow--light"><span className="eyebrow__code">BOOKINGS</span> Your reservations</p><h1>Booking history</h1><p>Keep track of your upcoming experiences and previous travel bookings.</p></div></section><section className="section"><div className="section__inner"><div className="booking-stats"><div><span>Total bookings</span><strong>{bookings.length}</strong></div><div><span>Upcoming</span><strong>{upcoming.length}</strong></div><div><span>Completed</span><strong>{bookings.filter(b=>b.bookingStatus==='Completed').length}</strong></div></div>{error&&<StateMessage tone="error">{error}</StateMessage>}{!bookings.length&&!error&&<StateMessage tone="info">You haven't made any bookings yet. <a href="/services">Browse services →</a></StateMessage>}<div className="booking-list">{bookings.map(b=><article className="booking-card booking-card--row" key={b._id}><div className="booking-service-image"><img src={b.service?.image||"https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=500&q=80"} alt=""/></div><div className="booking-info"><div className="booking-info__top"><span className={`trip-status trip-status--${b.bookingStatus.toLowerCase()}`}>{b.bookingStatus}</span><span className="mono">{b.bookingId}</span></div><h3>{b.service?.serviceName||"Travel service"}</h3><p>{b.service?.location}</p><div className="booking-meta"><span>📅 {new Date(b.bookingDate).toLocaleDateString()}</span><span>👥 {b.numberOfPeople}</span><strong>PKR {Number(b.totalPrice).toLocaleString()}</strong></div>{b.specialRequest&&<p className="booking-request">Request: {b.specialRequest}</p>}<div>{!['Cancelled','Completed'].includes(b.bookingStatus)&&<button className="link-btn link-btn--danger" onClick={()=>cancel(b._id)}>Cancel booking</button>}</div></div></article>)}</div></div></section></main><Footer/></>;
}
export default Bookings;
