import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import StateMessage from "../components/StateMessage.jsx";
import { toCode } from "../utils/code.js";
import { getDestinationById, deleteDestination, recordRecentlyViewed } from "../services/api.js";
import { useAuth } from "../context/AuthContext.jsx";
import ReviewSection from "../components/ReviewSection.jsx";

function DestinationDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [destination, setDestination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;

    const fetchOne = async () => {
      setLoading(true);
      setError("");
      try {
        const res = await getDestinationById(id);
        if (!cancelled) {
          setDestination(res.data);
          if (user) recordRecentlyViewed(id).catch(() => {});
        }
      } catch (err) {
        if (!cancelled) {
          if (err.response?.status === 404) {
            setError("This destination doesn't exist, or may have been removed.");
          } else if (err.response?.status === 400) {
            setError("That destination link looks invalid.");
          } else {
            setError("Couldn't reach the backend API. Make sure the server is running.");
          }
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    fetchOne();
    window.scrollTo({ top: 0 });
    return () => {
      cancelled = true;
    };
  }, [id, user]);

  const handleDelete = async () => {
    if (!window.confirm("Delete this destination? This can't be undone.")) return;
    await deleteDestination(id);
    navigate("/");
  };

  return (
    <>
      <Navbar />
      <main className="details">
        <div className="details__inner">
          <Link to="/#destinations" className="details__back">
            ← Back to all destinations
          </Link>

          {loading && (
            <div className="details__state">
              <StateMessage tone="info">Loading destination…</StateMessage>
            </div>
          )}

          {!loading && error && (
            <div className="details__state">
              <StateMessage tone="error">{error}</StateMessage>
            </div>
          )}

          {!loading && !error && destination && (
            <article className="details__card">
              <div className="details__image">
                <img src={destination.imageUrl} alt={destination.name} />
                <span className="ticket__category">{destination.category}</span>
                {destination.featured && <span className="ticket__featured">Featured</span>}
              </div>

              <div className="details__body">
                <div className="details__meta">
                  <span className="mono ticket__code">{toCode(destination.name)}</span>
                  <span className="ticket__rating">★ {destination.rating?.toFixed(1) ?? "4.5"}</span>
                </div>

                <h1 className="details__title">{destination.name}</h1>
                <p className="details__place">
                  {destination.city}, {destination.country}
                </p>

                <p className="details__desc">{destination.description}</p>

                {typeof destination.popularity === "number" && (
                  <p className="mono details__popularity">
                    🔥 {destination.popularity.toLocaleString()} travelers explored this in the last month
                  </p>
                )}

                <div className="details__actions">
                  <Link to="/#destinations" className="btn btn--ghost btn--sm">
                    Browse more destinations
                  </Link>
                  <button type="button" className="link-btn link-btn--danger" onClick={handleDelete}>
                    Delete this destination
                  </button>
                </div>
              </div>
            </article>
            <ReviewSection type="destination" targetId={id} />
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}

export default DestinationDetails;
