import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import StateMessage from "../components/StateMessage.jsx";
import { getServices } from "../services/api.js";

const categories = ["All", "Hotels", "Tours", "Transport", "Activities", "Guides"];

function Services() {
  const [services, setServices] = useState([]);
  const [category, setCategory] = useState("All");
  const [error, setError] = useState("");
  const load = async () => {
    try { const res = await getServices({ category }); setServices(res.data); }
    catch (err) { setError(err.response?.data?.message || "Could not load travel services."); }
  };
  useEffect(() => { load(); }, [category]);
  return <>
    <Navbar />
    <main>
      <section className="service-hero"><div><p className="eyebrow eyebrow--light"><span className="eyebrow__code">SERVICES</span> Travel made simple</p><h1>Book the experience, not just the destination.</h1><p>Discover hotels, tours, transport and activities, then reserve your place directly through Voyage.</p></div></section>
      <section className="section"><div className="section__inner">
        <div className="section__head"><p className="eyebrow"><span className="eyebrow__code">01</span> Explore</p><h2 className="section__title">Travel services</h2></div>
        <div className="pill-row">{categories.map(c => <button key={c} className={`pill ${category===c?"pill--active":""}`} onClick={()=>setCategory(c)}>{c}</button>)}</div>
        {error && <StateMessage tone="error">{error}</StateMessage>}
        {!error && !services.length && <StateMessage tone="info">No services found for this category.</StateMessage>}
        <div className="service-grid">{services.map(s => <article className="service-card" key={s._id}>
          <Link to={`/services/${s._id}`} className="service-card__image"><img src={s.image || "https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=900&q=80"} alt={s.serviceName}/><span>{s.category}</span></Link>
          <div className="service-card__body"><div className="service-card__top"><span className="mono">★ {Number(s.rating||0).toFixed(1)}</span><strong>PKR {Number(s.price).toLocaleString()}</strong></div><h3>{s.serviceName}</h3><p className="service-card__location">{s.location}</p><p>{s.description}</p><div className="service-features">{(s.features||[]).slice(0,3).map(f=><span key={f}>{f}</span>)}</div><Link className="btn btn--primary" to={`/services/${s._id}`}>View service</Link></div>
        </article>)}</div>
      </div></section>
    </main><Footer />
  </>;
}
export default Services;
