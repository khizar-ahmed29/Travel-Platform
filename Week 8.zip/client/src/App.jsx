import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home.jsx";
import DestinationDetails from "./pages/DestinationDetails.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Favorites from "./pages/Favorites.jsx";
import Profile from "./pages/Profile.jsx";
import Trips from "./pages/Trips.jsx";
import TripDetails from "./pages/TripDetails.jsx";
import Services from "./pages/Services.jsx";
import ServiceDetails from "./pages/ServiceDetails.jsx";
import BookingForm from "./pages/BookingForm.jsx";
import BookingConfirmation from "./pages/BookingConfirmation.jsx";
import Bookings from "./pages/Bookings.jsx";
import Recommendations from "./pages/Recommendations.jsx";
import MyReviews from "./pages/MyReviews.jsx";
import AdminDashboard from "./pages/AdminDashboard.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/destinations/:id" element={<DestinationDetails />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/services" element={<Services />} />
      <Route path="/services/:id" element={<ServiceDetails />} />

      <Route element={<ProtectedRoute />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/favorites" element={<Favorites />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/trips" element={<Trips />} />
        <Route path="/trips/:id" element={<TripDetails />} />
        <Route path="/services/:id/book" element={<BookingForm />} />
        <Route path="/bookings" element={<Bookings />} />
        <Route path="/bookings/confirmation/:id" element={<BookingConfirmation />} />
        <Route path="/recommendations" element={<Recommendations />} />
        <Route path="/my-reviews" element={<MyReviews />} />
      </Route>

      <Route element={<ProtectedRoute adminOnly />}>
        <Route path="/admin" element={<AdminDashboard />} />
      </Route>
    </Routes>
  );
}

export default App;
