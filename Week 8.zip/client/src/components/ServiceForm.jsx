import { useEffect, useState } from "react";

const CATEGORIES = ["Hotels", "Tours", "Transport", "Activities", "Guides"];

const EMPTY = {
  serviceName: "",
  category: "Hotels",
  location: "",
  description: "",
  image: "",
  price: 0,
  rating: 4.5,
  availability: true,
  features: "",
};

function ServiceForm({ initialData, onSubmit, onCancel, submitting }) {
  const [form, setForm] = useState(EMPTY);

  useEffect(() => {
    if (initialData) {
      setForm({ ...EMPTY, ...initialData, features: (initialData.features || []).join(", ") });
    } else {
      setForm(EMPTY);
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((prev) => ({ ...prev, [name]: type === "checkbox" ? checked : value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...form,
      price: Number(form.price),
      rating: Number(form.rating),
      features: form.features.split(",").map((f) => f.trim()).filter(Boolean),
    });
  };

  return (
    <form className="dest-form" onSubmit={handleSubmit}>
      <div className="dest-form__grid">
        <label>
          Service name
          <input name="serviceName" value={form.serviceName} onChange={handleChange} required placeholder="e.g. Skyline Suites" />
        </label>
        <label>
          Category
          <select name="category" value={form.category} onChange={handleChange}>
            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>
        <label>
          Location
          <input name="location" value={form.location} onChange={handleChange} required placeholder="e.g. Karachi" />
        </label>
        <label>
          Price (PKR)
          <input type="number" name="price" value={form.price} onChange={handleChange} min="0" step="1" required />
        </label>
        <label className="dest-form__wide">
          Image URL
          <input name="image" value={form.image} onChange={handleChange} placeholder="https://..." />
        </label>
        <label>
          Rating (0–5)
          <input type="number" name="rating" value={form.rating} onChange={handleChange} min="0" max="5" step="0.1" />
        </label>
        <label className="dest-form__checkbox">
          <input type="checkbox" name="availability" checked={form.availability} onChange={handleChange} />
          Available for booking
        </label>
        <label className="dest-form__wide">
          Description
          <textarea name="description" value={form.description} onChange={handleChange} required rows={3} placeholder="What does this service include?" />
        </label>
        <label className="dest-form__wide">
          Features (comma separated)
          <input name="features" value={form.features} onChange={handleChange} placeholder="Free WiFi, Breakfast included, Airport pickup" />
        </label>
      </div>

      <div className="dest-form__actions">
        <button type="submit" className="btn btn--primary btn--sm" disabled={submitting}>
          {submitting ? "Saving..." : initialData ? "Save changes" : "Add service"}
        </button>
        <button type="button" className="btn btn--ghost btn--sm" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}

export default ServiceForm;
