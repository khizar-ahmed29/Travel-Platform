import { useState } from "react";
import DestinationCard from "./DestinationCard.jsx";
import DestinationForm from "./DestinationForm.jsx";
import SearchBar from "./SearchBar.jsx";
import StateMessage from "./StateMessage.jsx";

const SORT_OPTIONS = [
  { value: "newest", label: "Newest" },
  { value: "rating", label: "Top rated" },
  { value: "popularity", label: "Most popular" },
  { value: "name", label: "Name (A–Z)" },
];

function DestinationsSection({
  destinations,
  categories,
  loading,
  error,
  activeCategory,
  onCategoryChange,
  searchTerm,
  onSearchChange,
  sortBy,
  onSortChange,
  onCreate,
  onUpdate,
  onDelete,
  canManage = false,
}) {
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const openCreate = () => {
    setEditing(null);
    setFormOpen(true);
  };

  const openEdit = (destination) => {
    setEditing(destination);
    setFormOpen(true);
    window.scrollTo({ top: document.getElementById("destinations").offsetTop - 90, behavior: "smooth" });
  };

  const closeForm = () => {
    setFormOpen(false);
    setEditing(null);
  };

  const handleSubmit = async (payload) => {
    setSubmitting(true);
    try {
      if (editing) {
        await onUpdate(editing._id, payload);
      } else {
        await onCreate(payload);
      }
      closeForm();
    } finally {
      setSubmitting(false);
    }
  };

  const hasActiveFilters = Boolean(activeCategory || searchTerm);

  return (
    <section className="section" id="destinations">
      <div className="section__inner">
        <div className="section__head">
          <p className="eyebrow">
            <span className="eyebrow__code">ALL</span> The full route map
          </p>
          <h2 className="section__title">Every destination, straight from the database</h2>
          {canManage && (
            <button type="button" className="btn btn--primary btn--sm" onClick={formOpen ? closeForm : openCreate}>
              {formOpen ? "Close form" : "Add a destination"}
            </button>
          )}
        </div>

        {canManage && formOpen && (
          <DestinationForm
            initialData={editing}
            onSubmit={handleSubmit}
            onCancel={closeForm}
            submitting={submitting}
          />
        )}

        <div className="explore-bar">
          <SearchBar value={searchTerm} onChange={onSearchChange} />

          <label className="sort-select">
            Sort by
            <select value={sortBy} onChange={(e) => onSortChange(e.target.value)}>
              {SORT_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="pill-row" role="tablist" aria-label="Filter by category">
          <button
            className={`pill ${activeCategory === "" ? "pill--active" : ""}`}
            onClick={() => onCategoryChange("")}
          >
            All
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              className={`pill ${activeCategory === cat ? "pill--active" : ""}`}
              onClick={() => onCategoryChange(cat)}
            >
              {cat}
            </button>
          ))}
        </div>

        {loading && <StateMessage tone="info">Loading destinations…</StateMessage>}
        {error && <StateMessage tone="error">{error}</StateMessage>}
        {!loading && !error && destinations.length === 0 && hasActiveFilters && (
          <StateMessage tone="info">
            No destinations match "{searchTerm || activeCategory}". Try a different search or category.
          </StateMessage>
        )}
        {!loading && !error && destinations.length === 0 && !hasActiveFilters && (
          <StateMessage tone="info">No destinations yet — add the first one above.</StateMessage>
        )}

        <div className="ticket-grid">
          {destinations.map((dest) => (
            <DestinationCard
              key={dest._id}
              destination={dest}
              editable={canManage}
              onEdit={openEdit}
              onDelete={onDelete}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

export default DestinationsSection;
