import { useCallback, useEffect, useMemo, useState } from "react";
import Navbar from "../components/Navbar.jsx";
import Hero from "../components/Hero.jsx";
import DestinationsSection from "../components/DestinationsSection.jsx";
import FeaturedDestinations from "../components/FeaturedDestinations.jsx";
import Categories from "../components/Categories.jsx";
import About from "../components/About.jsx";
import Footer from "../components/Footer.jsx";
import { useAuth } from "../context/AuthContext.jsx";
import {
  getDestinations,
  createDestination,
  updateDestination,
  deleteDestination,
} from "../services/api.js";

function Home() {
  const { user } = useAuth();
  // Unfiltered snapshot — powers stats, categories, and featured picks.
  const [allDestinations, setAllDestinations] = useState([]);
  const [loadingAll, setLoadingAll] = useState(true);
  const [errorAll, setErrorAll] = useState("");

  // Filtered/search/sorted results shown in the main Destinations grid.
  const [filteredDestinations, setFilteredDestinations] = useState([]);
  const [loadingFiltered, setLoadingFiltered] = useState(true);
  const [errorFiltered, setErrorFiltered] = useState("");

  const [activeCategory, setActiveCategory] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("newest");

  const fetchAll = useCallback(async () => {
    setLoadingAll(true);
    setErrorAll("");
    try {
      const res = await getDestinations();
      setAllDestinations(res.data || []);
    } catch (err) {
      setErrorAll("Couldn't reach the backend API. Make sure the server is running.");
    } finally {
      setLoadingAll(false);
    }
  }, []);

  const fetchFiltered = useCallback(async () => {
    setLoadingFiltered(true);
    setErrorFiltered("");
    try {
      const params = { sort: sortBy };
      if (activeCategory) params.category = activeCategory;
      if (searchTerm) params.search = searchTerm;
      const res = await getDestinations(params);
      setFilteredDestinations(res.data || []);
    } catch (err) {
      setErrorFiltered("Couldn't reach the backend API. Make sure the server is running.");
    } finally {
      setLoadingFiltered(false);
    }
  }, [activeCategory, searchTerm, sortBy]);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  useEffect(() => {
    fetchFiltered();
  }, [fetchFiltered]);

  const featured = useMemo(() => allDestinations.filter((d) => d.featured), [allDestinations]);

  const categories = useMemo(
    () => [...new Set(allDestinations.map((d) => d.category))],
    [allDestinations]
  );

  const categoryCounts = useMemo(() => {
    return allDestinations.reduce((acc, d) => {
      acc[d.category] = (acc[d.category] || 0) + 1;
      return acc;
    }, {});
  }, [allDestinations]);

  const stats = useMemo(
    () => ({
      destinationCount: allDestinations.length,
      countryCount: new Set(allDestinations.map((d) => d.country)).size,
      categoryCount: categories.length,
    }),
    [allDestinations, categories]
  );

  const refreshEverything = async () => {
    await Promise.all([fetchAll(), fetchFiltered()]);
  };

  const handleCreate = async (payload) => {
    await createDestination(payload);
    await refreshEverything();
  };

  const handleUpdate = async (id, payload) => {
    await updateDestination(id, payload);
    await refreshEverything();
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this destination? This can't be undone.")) return;
    await deleteDestination(id);
    await refreshEverything();
  };

  const jumpToCategory = (cat) => {
    setActiveCategory(cat);
    document.getElementById("destinations")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <Navbar />
      <main>
        <Hero stats={stats} />
        <DestinationsSection
          destinations={filteredDestinations}
          categories={categories}
          loading={loadingFiltered}
          error={errorFiltered || errorAll}
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          sortBy={sortBy}
          onSortChange={setSortBy}
          onCreate={handleCreate}
          onUpdate={handleUpdate}
          onDelete={handleDelete}
          canManage={user?.role === "admin"}
        />
        <FeaturedDestinations destinations={featured} loading={loadingAll} />
        <Categories counts={categoryCounts} onSelect={jumpToCategory} />
        <About stats={stats} />
      </main>
      <Footer />
    </>
  );
}

export default Home;
