import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import StateMessage from "../components/StateMessage.jsx";
import { getMyReviews, updateReview, deleteReview } from "../services/api.js";

const Stars = ({ value }) => (
  <span className="review-stars review-stars--static" aria-label={`${value} out of 5 stars`}>
    {[1, 2, 3, 4, 5].map((n) => (
      <span key={n} className={n <= value ? "is-active" : ""}>★</span>
    ))}
  </span>
);

function MyReviews() {
  const [reviews, setReviews] = useState(null);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(null);
  const [draft, setDraft] = useState({ rating: 5, reviewText: "" });
  const [message, setMessage] = useState("");

  const load = async () => {
    try {
      const res = await getMyReviews();
      setReviews(res.data);
    } catch (err) {
      setError(err.response?.data?.message || "Could not load your reviews.");
    }
  };

  useEffect(() => { load(); }, []);

  const startEdit = (review) => {
    setEditing(review._id);
    setDraft({ rating: review.rating, reviewText: review.reviewText });
    setMessage("");
  };

  const saveEdit = async (id) => {
    try {
      await updateReview(id, draft);
      setEditing(null);
      await load();
    } catch (err) {
      setMessage(err.response?.data?.message || "Could not update review.");
    }
  };

  const remove = async (id) => {
    if (!confirm("Delete this review?")) return;
    try {
      await deleteReview(id);
      await load();
    } catch (err) {
      setMessage(err.response?.data?.message || "Could not delete review.");
    }
  };

  const targetFor = (review) => {
    if (review.destination) return { label: review.destination.name, href: `/destinations/${review.destination._id}`, image: review.destination.imageUrl };
    if (review.service) return { label: review.service.serviceName, href: `/services/${review.service._id}`, image: review.service.image };
    return { label: "Deleted item", href: "#", image: "" };
  };

  return (
    <>
      <Navbar />
      <main>
        <section className="trip-hero">
          <div>
            <p className="eyebrow eyebrow--light"><span className="eyebrow__code">REVIEWS</span> Your feedback</p>
            <h1>My reviews</h1>
            <p>Every rating and review you've left across destinations and travel services.</p>
          </div>
        </section>

        <section className="section">
          <div className="section__inner">
            {error && <StateMessage tone="error">{error}</StateMessage>}
            {message && <StateMessage tone="error">{message}</StateMessage>}

            {!reviews && !error && <StateMessage tone="info">Loading your reviews…</StateMessage>}

            {reviews && reviews.length === 0 && (
              <StateMessage tone="info">
                You haven't written any reviews yet. <Link to="/">Explore destinations →</Link>
              </StateMessage>
            )}

            {reviews && reviews.length > 0 && (
              <div className="review-list">
                {reviews.map((review) => {
                  const target = targetFor(review);
                  const isEditing = editing === review._id;
                  return (
                    <article className="review-card" key={review._id}>
                      <div className="review-card__top">
                        <Link to={target.href} className="review-author">
                          {target.image ? <img src={target.image} alt="" /> : <span>{target.label?.[0] || "V"}</span>}
                          <div>
                            <strong>{target.label}</strong>
                            <small>{new Date(review.createdAt).toLocaleDateString()}</small>
                          </div>
                        </Link>
                        {!isEditing && <Stars value={review.rating} />}
                      </div>

                      {isEditing ? (
                        <div className="review-form">
                          <div className="review-stars">
                            {[1, 2, 3, 4, 5].map((n) => (
                              <button
                                key={n}
                                type="button"
                                className={n <= draft.rating ? "is-active" : ""}
                                onClick={() => setDraft((d) => ({ ...d, rating: n }))}
                              >★</button>
                            ))}
                          </div>
                          <textarea
                            value={draft.reviewText}
                            onChange={(e) => setDraft((d) => ({ ...d, reviewText: e.target.value }))}
                            maxLength={1000}
                          />
                          <div className="review-form__actions">
                            <button className="btn btn--primary" onClick={() => saveEdit(review._id)}>Save changes</button>
                            <button className="btn btn--ghost" onClick={() => setEditing(null)}>Cancel</button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <p>{review.reviewText}</p>
                          {review.image && <img className="review-image" src={review.image} alt="Review" />}
                          <div className="review-card__actions">
                            <span>Helpful ({review.helpfulCount || 0})</span>
                            <button type="button" onClick={() => startEdit(review)}>Edit</button>
                            <button type="button" onClick={() => remove(review._id)}>Delete</button>
                          </div>
                        </>
                      )}
                    </article>
                  );
                })}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

export default MyReviews;
