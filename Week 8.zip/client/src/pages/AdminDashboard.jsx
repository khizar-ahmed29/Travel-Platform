import { useEffect, useState } from "react";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import StateMessage from "../components/StateMessage.jsx";
import DestinationForm from "../components/DestinationForm.jsx";
import ServiceForm from "../components/ServiceForm.jsx";
import { useAuth } from "../context/AuthContext.jsx";
import {
  getAdminStats,
  getAdminUsers,
  updateUserRole,
  deleteUserAccount,
  getAdminBookings,
  updateBookingStatus,
  getDestinations,
  createDestination,
  updateDestination,
  deleteDestination,
  getServices,
  createService,
  updateService,
  deleteService,
} from "../services/api.js";

const TABS = ["Overview", "Users", "Bookings", "Destinations", "Services"];
const BOOKING_STATUSES = ["Pending", "Confirmed", "Cancelled", "Completed"];

function AdminDashboard() {
  const { user } = useAuth();
  const [tab, setTab] = useState("Overview");
  const [error, setError] = useState("");

  const [stats, setStats] = useState(null);

  const [users, setUsers] = useState(null);
  const [bookings, setBookings] = useState(null);

  const [destinations, setDestinations] = useState(null);
  const [destForm, setDestForm] = useState(false);
  const [editingDest, setEditingDest] = useState(null);

  const [services, setServices] = useState(null);
  const [serviceForm, setServiceForm] = useState(false);
  const [editingService, setEditingService] = useState(null);

  const [submitting, setSubmitting] = useState(false);

  const loadStats = () => getAdminStats().then((r) => setStats(r.data)).catch((e) => setError(e.response?.data?.message || "Could not load statistics."));
  const loadUsers = () => getAdminUsers().then((r) => setUsers(r.data)).catch((e) => setError(e.response?.data?.message || "Could not load users."));
  const loadBookings = () => getAdminBookings().then((r) => setBookings(r.data)).catch((e) => setError(e.response?.data?.message || "Could not load bookings."));
  const loadDestinations = () => getDestinations().then((r) => setDestinations(r.data)).catch((e) => setError(e.response?.data?.message || "Could not load destinations."));
  const loadServices = () => getServices().then((r) => setServices(r.data)).catch((e) => setError(e.response?.data?.message || "Could not load services."));

  useEffect(() => {
    setError("");
    if (tab === "Overview" && !stats) loadStats();
    if (tab === "Users" && !users) loadUsers();
    if (tab === "Bookings" && !bookings) loadBookings();
    if (tab === "Destinations" && !destinations) loadDestinations();
    if (tab === "Services" && !services) loadServices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const changeRole = async (id, role) => {
    try { await updateUserRole(id, role); await loadUsers(); }
    catch (e) { setError(e.response?.data?.message || "Could not update role."); }
  };

  const removeUser = async (id) => {
    if (!confirm("Delete this user account? This cannot be undone.")) return;
    try { await deleteUserAccount(id); await loadUsers(); }
    catch (e) { setError(e.response?.data?.message || "Could not delete user."); }
  };

  const changeBookingStatus = async (id, status) => {
    try { await updateBookingStatus(id, status); await loadBookings(); await loadStats(); }
    catch (e) { setError(e.response?.data?.message || "Could not update booking status."); }
  };

  const submitDestination = async (payload) => {
    setSubmitting(true);
    try {
      if (editingDest) await updateDestination(editingDest._id, payload);
      else await createDestination(payload);
      setDestForm(false); setEditingDest(null);
      await loadDestinations();
    } catch (e) { setError(e.response?.data?.message || "Could not save destination."); }
    finally { setSubmitting(false); }
  };

  const removeDestination = async (id) => {
    if (!confirm("Delete this destination? This cannot be undone.")) return;
    try { await deleteDestination(id); await loadDestinations(); }
    catch (e) { setError(e.response?.data?.message || "Could not delete destination."); }
  };

  const submitService = async (payload) => {
    setSubmitting(true);
    try {
      if (editingService) await updateService(editingService._id, payload);
      else await createService(payload);
      setServiceForm(false); setEditingService(null);
      await loadServices();
    } catch (e) { setError(e.response?.data?.message || "Could not save service."); }
    finally { setSubmitting(false); }
  };

  const removeService = async (id) => {
    if (!confirm("Delete this service? This cannot be undone.")) return;
    try { await deleteService(id); await loadServices(); }
    catch (e) { setError(e.response?.data?.message || "Could not delete service."); }
  };

  return (
    <>
      <Navbar />
      <main>
        <section className="trip-hero">
          <div>
            <p className="eyebrow eyebrow--light"><span className="eyebrow__code">ADMIN</span> Control center</p>
            <h1>Admin dashboard</h1>
            <p>Signed in as {user?.name} — manage the platform's data, users and bookings.</p>
          </div>
        </section>

        <section className="section">
          <div className="section__inner">
            <div className="pill-row" role="tablist" aria-label="Admin sections">
              {TABS.map((t) => (
                <button key={t} className={`pill ${tab === t ? "pill--active" : ""}`} onClick={() => setTab(t)}>{t}</button>
              ))}
            </div>

            {error && <StateMessage tone="error">{error}</StateMessage>}

            {tab === "Overview" && (
              !stats ? <StateMessage tone="info">Loading statistics…</StateMessage> : (
                <>
                  <div className="dashboard-stats">
                    <div><span>Users</span><strong>{stats.counts.users}</strong></div>
                    <div><span>Destinations</span><strong>{stats.counts.destinations}</strong></div>
                    <div><span>Services</span><strong>{stats.counts.services}</strong></div>
                    <div><span>Bookings</span><strong>{stats.counts.bookings}</strong></div>
                    <div><span>Reviews</span><strong>{stats.counts.reviews}</strong></div>
                    <div><span>Avg. rating</span><strong>{stats.averageRating} ★</strong></div>
                    <div><span>Revenue (confirmed+)</span><strong>PKR {Number(stats.totalRevenue).toLocaleString()}</strong></div>
                  </div>

                  <div className="admin-status-grid">
                    {BOOKING_STATUSES.map((s) => (
                      <div key={s} className={`trip-status trip-status--${s.toLowerCase()} admin-status-chip`}>
                        {s}: {stats.bookingsByStatus[s] || 0}
                      </div>
                    ))}
                  </div>

                  <h3 className="admin-subheading">Recent bookings</h3>
                  <div className="admin-table-wrap">
                    <table className="admin-table">
                      <thead><tr><th>Booking</th><th>User</th><th>Service</th><th>Status</th></tr></thead>
                      <tbody>
                        {stats.recentBookings.map((b) => (
                          <tr key={b._id}>
                            <td className="mono">{b.bookingId}</td>
                            <td>{b.user?.name || "—"}</td>
                            <td>{b.service?.serviceName || "—"}</td>
                            <td><span className={`trip-status trip-status--${b.bookingStatus.toLowerCase()}`}>{b.bookingStatus}</span></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )
            )}

            {tab === "Users" && (
              !users ? <StateMessage tone="info">Loading users…</StateMessage> : (
                <div className="admin-table-wrap">
                  <table className="admin-table">
                    <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th><th></th></tr></thead>
                    <tbody>
                      {users.map((u) => (
                        <tr key={u._id}>
                          <td>{u.name}</td>
                          <td>{u.email}</td>
                          <td>
                            <select value={u.role} onChange={(e) => changeRole(u._id, e.target.value)} disabled={u._id === user?._id}>
                              <option value="user">user</option>
                              <option value="admin">admin</option>
                            </select>
                          </td>
                          <td>{new Date(u.createdAt).toLocaleDateString()}</td>
                          <td>{u._id !== user?._id && <button className="link-btn link-btn--danger" onClick={() => removeUser(u._id)}>Delete</button>}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )
            )}

            {tab === "Bookings" && (
              !bookings ? <StateMessage tone="info">Loading bookings…</StateMessage> : (
                <div className="admin-table-wrap">
                  <table className="admin-table">
                    <thead><tr><th>Booking</th><th>User</th><th>Service</th><th>Date</th><th>Total</th><th>Status</th></tr></thead>
                    <tbody>
                      {bookings.map((b) => (
                        <tr key={b._id}>
                          <td className="mono">{b.bookingId}</td>
                          <td>{b.user?.name}<br /><small>{b.user?.email}</small></td>
                          <td>{b.service?.serviceName}</td>
                          <td>{new Date(b.bookingDate).toLocaleDateString()}</td>
                          <td>PKR {Number(b.totalPrice).toLocaleString()}</td>
                          <td>
                            <select value={b.bookingStatus} onChange={(e) => changeBookingStatus(b._id, e.target.value)}>
                              {BOOKING_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {bookings.length === 0 && <StateMessage tone="info">No bookings yet.</StateMessage>}
                </div>
              )
            )}

            {tab === "Destinations" && (
              <>
                <div className="section__head">
                  <h2 className="section__title">Manage destinations</h2>
                  <button className="btn btn--primary btn--sm" onClick={() => { setEditingDest(null); setDestForm((v) => !v); }}>
                    {destForm ? "Close form" : "Add a destination"}
                  </button>
                </div>
                {destForm && <DestinationForm initialData={editingDest} onSubmit={submitDestination} onCancel={() => setDestForm(false)} submitting={submitting} />}
                {!destinations ? <StateMessage tone="info">Loading destinations…</StateMessage> : (
                  <div className="admin-table-wrap">
                    <table className="admin-table">
                      <thead><tr><th>Name</th><th>Country</th><th>Category</th><th>Rating</th><th></th></tr></thead>
                      <tbody>
                        {destinations.map((d) => (
                          <tr key={d._id}>
                            <td>{d.name}</td><td>{d.country}</td><td>{d.category}</td><td>{d.rating}</td>
                            <td>
                              <button className="link-btn" onClick={() => { setEditingDest(d); setDestForm(true); }}>Edit</button>{" "}
                              <button className="link-btn link-btn--danger" onClick={() => removeDestination(d._id)}>Delete</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}

            {tab === "Services" && (
              <>
                <div className="section__head">
                  <h2 className="section__title">Manage services</h2>
                  <button className="btn btn--primary btn--sm" onClick={() => { setEditingService(null); setServiceForm((v) => !v); }}>
                    {serviceForm ? "Close form" : "Add a service"}
                  </button>
                </div>
                {serviceForm && <ServiceForm initialData={editingService} onSubmit={submitService} onCancel={() => setServiceForm(false)} submitting={submitting} />}
                {!services ? <StateMessage tone="info">Loading services…</StateMessage> : (
                  <div className="admin-table-wrap">
                    <table className="admin-table">
                      <thead><tr><th>Name</th><th>Category</th><th>Price</th><th>Available</th><th></th></tr></thead>
                      <tbody>
                        {services.map((s) => (
                          <tr key={s._id}>
                            <td>{s.serviceName}</td><td>{s.category}</td><td>PKR {Number(s.price).toLocaleString()}</td>
                            <td>{s.availability ? "Yes" : "No"}</td>
                            <td>
                              <button className="link-btn" onClick={() => { setEditingService(s); setServiceForm(true); }}>Edit</button>{" "}
                              <button className="link-btn link-btn--danger" onClick={() => removeService(s._id)}>Delete</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

export default AdminDashboard;
