# Voyage API Documentation

Base URL: `http://localhost:5000/api` (or `VITE_API_URL` in `client/.env`)

All responses follow the shape:
```json
{ "success": true, "data": {}, "message": "optional" }
```
Errors use `"success": false` with a `message`, and validation errors return HTTP 400.

Protected routes require an `Authorization: Bearer <token>` header. Admin-only
routes additionally require the authenticated user's account to have
`role: "admin"` (see "Roles & Admin access" below).

---

## Auth — `/api/auth`
| Method | Route | Auth | Description |
|---|---|---|---|
| POST | `/register` | Public | Create an account. Body: `name, email, password, profileImage?, bio?` |
| POST | `/login` | Public | Log in. Body: `email, password` → returns `token` + `user` |
| GET | `/me` | Protected | Returns the current authenticated user |

## Users — `/api/users` (all protected)
| Method | Route | Description |
|---|---|---|
| GET | `/dashboard` | Personalized dashboard: favorites, recently viewed, recommendations, stats |
| GET | `/favorites` | List saved destinations |
| POST | `/favorites/:destinationId` | Save a destination |
| DELETE | `/favorites/:destinationId` | Remove a saved destination |
| POST | `/recently-viewed/:destinationId` | Record a destination view |
| PUT | `/profile` | Update name/bio/profileImage |

## Destinations — `/api/destinations`
| Method | Route | Auth | Description |
|---|---|---|---|
| GET | `/` | Public | List destinations. Query: `category`, `featured=true`, `search`, `sort=newest\|rating\|popularity\|name` |
| GET | `/category/:category` | Public | List by category |
| GET | `/:id` | Public | Get one destination |
| POST | `/` | Admin | Create a destination |
| PUT | `/:id` | Admin | Update a destination |
| DELETE | `/:id` | Admin | Delete a destination |

## Travel services — `/api/services`
| Method | Route | Auth | Description |
|---|---|---|---|
| GET | `/` | Public | List services. Query: `category` |
| GET | `/:id` | Public | Get one service |
| POST | `/` | Admin | Create a service |
| PUT | `/:id` | Admin | Update a service |
| DELETE | `/:id` | Admin | Delete a service |

## Bookings — `/api/bookings` (all protected, scoped to the logged-in user)
| Method | Route | Description |
|---|---|---|
| POST | `/` | Create a booking. Body: `serviceId, bookingDate, numberOfPeople, specialRequest?` |
| GET | `/` | List your bookings |
| GET | `/:id` | Get one of your bookings |
| PUT | `/:id` | Update date/people/status of your booking (if not cancelled/completed) |
| PATCH | `/:id/cancel` | Cancel your booking |

## Reviews & ratings — `/api/reviews`
| Method | Route | Auth | Description |
|---|---|---|---|
| GET | `/` | Public | Reviews for a target. Query: `type=destination\|service`, `id`, `rating?`, `sort=newest\|helpful\|highest\|lowest`. Returns `data` + rating `stats` |
| GET | `/mine` | Protected | All reviews written by the current user |
| GET | `/:id` | Public | Get a single review |
| POST | `/` | Protected | Create a review. Body: `type, targetId, rating (1-5), reviewText, image?` |
| PUT | `/:id` | Protected (owner) | Update your own review |
| DELETE | `/:id` | Protected (owner) | Delete your own review |
| PATCH | `/:id/helpful` | Public | Increment a review's helpful count |

## Recommendations — `/api/recommendations` (protected)
| Method | Route | Description |
|---|---|---|
| GET | `/preferences` | Get saved travel preferences |
| POST | `/preferences` | Create travel preferences |
| PUT | `/preferences` | Update travel preferences |
| GET | `/` | Ranked destination + service recommendations with match % and reasons |

## Trips & itineraries — `/api/trips` (all protected)
| Method | Route | Description |
|---|---|---|
| GET / POST | `/` | List / create your trips |
| GET / PUT / DELETE | `/:id` | Get / update / delete a trip |
| POST | `/:id/activities` | Add an itinerary activity |
| PUT / DELETE | `/:id/activities/:activityId` | Update / remove an activity |

## Admin — `/api/admin` (all routes require an admin account)
| Method | Route | Description |
|---|---|---|
| GET | `/stats` | Platform analytics: counts, revenue, bookings-by-status, average rating, recent bookings |
| GET | `/users` | List all user accounts |
| PATCH | `/users/:id/role` | Promote/demote a user. Body: `{ "role": "admin" \| "user" }` |
| DELETE | `/users/:id` | Delete a user account |
| GET | `/bookings` | List every booking on the platform. Query: `status?` |
| PATCH | `/bookings/:id/status` | Override any booking's status. Body: `{ "bookingStatus": "Pending"\|"Confirmed"\|"Cancelled"\|"Completed" }` |

---

## Roles & Admin access

Every new account registers with `role: "user"`. To get an admin account:

```bash
cd server
# set ADMIN_NAME / ADMIN_EMAIL / ADMIN_PASSWORD in .env, or use the defaults
npm run seed:admin
```

This creates the account (or promotes it, if the email already exists) and
prints the login credentials. Log in with that account and an **Admin** link
appears in the navbar, unlocking `/admin`.

Because destination/service management is now admin-only, the "Add a
destination" control on the homepage is hidden unless you're logged in as an
admin.
