# Week 7 — Full-Stack Finalization

This update finalizes Voyage into the complete MERN platform requested for
Week 7, closing the two gaps left after Week 6 and adding the advanced
(bonus) features listed on the brief.

## What's new

**Core requirement — "My Reviews"**
- `GET /api/reviews/mine` returns every review the logged-in user has written
- New `/my-reviews` page lets users view, edit and delete their own reviews
  across both destinations and services, in one place
- Linked from the navbar for any logged-in user

**Advanced — Role-based access & Admin dashboard**
- `User` model now has a `role` (`user` | `admin`)
- New `adminOnly` middleware protects admin-only routes
- Destination and service **create/update/delete** are now admin-only
  (previously unauthenticated — anyone could add/edit/delete them)
- New `/api/admin/*` routes: platform stats, user management (promote/demote/
  delete), and full booking-status management across every user's bookings
- New `/admin` dashboard page (visible only to admins) with tabs for
  Overview, Users, Bookings, Destinations and Services — reusing the existing
  destination form and a new service form for create/edit
- `npm run seed:admin` (from `server/`) creates or promotes an admin account
  using `ADMIN_NAME` / `ADMIN_EMAIL` / `ADMIN_PASSWORD` from `.env`

**Documentation**
- `API_DOCUMENTATION.md` at the project root consolidates every route across
  all modules (auth, users, destinations, services, bookings, reviews,
  recommendations, trips, admin) into one reference

## Everything already in place from earlier weeks

Destinations, travel services, bookings, reviews & ratings, favorites,
recommendations, JWT authentication, and trip/itinerary planning were already
fully wired end-to-end (see `README.md`, `README_WEEK4.md`,
`README_WEEK6.md`, `README_AUTHENTICATION.md`). This update only adds the
pieces above.

## Run it

Same setup as before — see the root `README.md` for MongoDB/env setup.

```bash
# backend
cd server
npm install
npm run seed         # sample destinations
npm run seed:services
npm run seed:admin    # creates/promotes an admin account
npm run dev

# frontend
cd client
npm install
npm run dev
```

Log in with the admin account printed by `seed:admin` and open **Admin** in
the navbar.
