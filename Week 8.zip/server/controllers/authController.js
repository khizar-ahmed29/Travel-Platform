const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d",
  });

const publicUser = (user) => ({
  _id: user._id,
  name: user.name,
  email: user.email,
  profileImage: user.profileImage || "",
  bio: user.bio || "",
  role: user.role || "user",
  favoriteCount: user.favorites?.length || 0,
});

const register = async (req, res) => {
  try {
    const { name, email, password, profileImage = "", bio = "" } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "Name, email and password are required",
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: "Password must be at least 6 characters",
      });
    }

    const existing = await User.findOne({ email: email.toLowerCase().trim() });
    if (existing) {
      return res.status(409).json({
        success: false,
        message: "An account with this email already exists",
      });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      profileImage,
      bio,
    });

    res.status(201).json({
      success: true,
      message: "Account created successfully",
      token: signToken(user._id),
      user: publicUser(user),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server error while registering",
      error: error.message,
    });
  }
};

const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required",
      });
    }

    const user = await User.findOne({ email: email.toLowerCase().trim() }).select("+password");
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password",
      });
    }

    const safeUser = await User.findById(user._id);

    res.status(200).json({
      success: true,
      message: "Logged in successfully",
      token: signToken(user._id),
      user: publicUser(safeUser),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server error while logging in",
      error: error.message,
    });
  }
};

const me = async (req, res) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    res.json({ success: true, user: publicUser(user) });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server error while loading profile",
      error: error.message,
    });
  }
};

module.exports = { register, login, me, publicUser };
