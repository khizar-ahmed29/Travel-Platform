const User = require("../models/User");
const Destination = require("../models/Destination");
const Service = require("../models/Service");
const Booking = require("../models/Booking");
const Review = require("../models/Review");

// @desc    Platform-wide analytics for the admin dashboard
// @route   GET /api/admin/stats
const getStats = async (req, res) => {
  try {
    const [userCount, destinationCount, serviceCount, bookingCount, reviewCount] = await Promise.all([
      User.countDocuments(),
      Destination.countDocuments(),
      Service.countDocuments(),
      Booking.countDocuments(),
      Review.countDocuments(),
    ]);

    const revenueAgg = await Booking.aggregate([
      { $match: { bookingStatus: { $in: ["Confirmed", "Completed"] } } },
      { $group: { _id: null, total: { $sum: "$totalPrice" } } },
    ]);

    const bookingsByStatus = await Booking.aggregate([
      { $group: { _id: "$bookingStatus", count: { $sum: 1 } } },
    ]);
    const statusBreakdown = { Pending: 0, Confirmed: 0, Cancelled: 0, Completed: 0 };
    bookingsByStatus.forEach((row) => { statusBreakdown[row._id] = row.count; });

    const ratingAgg = await Review.aggregate([
      { $group: { _id: null, averageRating: { $avg: "$rating" } } },
    ]);

    const recentBookings = await Booking.find()
      .sort({ createdAt: -1 })
      .limit(5)
      .populate("user", "name email")
      .populate("service", "serviceName");

    res.json({
      success: true,
      data: {
        counts: {
          users: userCount,
          destinations: destinationCount,
          services: serviceCount,
          bookings: bookingCount,
          reviews: reviewCount,
        },
        totalRevenue: revenueAgg[0]?.total || 0,
        bookingsByStatus: statusBreakdown,
        averageRating: Number((ratingAgg[0]?.averageRating || 0).toFixed(1)),
        recentBookings,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not load admin statistics", error: error.message });
  }
};

// @desc    List all users (no passwords)
// @route   GET /api/admin/users
const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().sort({ createdAt: -1 });
    res.json({ success: true, count: users.length, data: users });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not load users", error: error.message });
  }
};

// @desc    Promote/demote a user's role
// @route   PATCH /api/admin/users/:id/role
const updateUserRole = async (req, res) => {
  try {
    const { role } = req.body;
    if (!["user", "admin"].includes(role)) {
      return res.status(400).json({ success: false, message: "Role must be 'user' or 'admin'" });
    }
    if (req.params.id === req.userId) {
      return res.status(400).json({ success: false, message: "You cannot change your own role" });
    }
    const user = await User.findByIdAndUpdate(req.params.id, { role }, { new: true });
    if (!user) return res.status(404).json({ success: false, message: "User not found" });
    res.json({ success: true, message: "Role updated", data: user });
  } catch (error) {
    res.status(400).json({ success: false, message: "Could not update role", error: error.message });
  }
};

// @desc    Remove a user account
// @route   DELETE /api/admin/users/:id
const deleteUser = async (req, res) => {
  try {
    if (req.params.id === req.userId) {
      return res.status(400).json({ success: false, message: "You cannot delete your own account" });
    }
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: "User not found" });
    res.json({ success: true, message: "User deleted" });
  } catch (error) {
    res.status(400).json({ success: false, message: "Could not delete user", error: error.message });
  }
};

// @desc    List every booking on the platform
// @route   GET /api/admin/bookings
const getAllBookings = async (req, res) => {
  try {
    const filter = {};
    if (req.query.status) filter.bookingStatus = req.query.status;
    const bookings = await Booking.find(filter)
      .sort({ createdAt: -1 })
      .populate("user", "name email")
      .populate("service", "serviceName location price");
    res.json({ success: true, count: bookings.length, data: bookings });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not load bookings", error: error.message });
  }
};

// @desc    Update the status of any booking (admin override)
// @route   PATCH /api/admin/bookings/:id/status
const updateBookingStatus = async (req, res) => {
  try {
    const { bookingStatus } = req.body;
    if (!["Pending", "Confirmed", "Cancelled", "Completed"].includes(bookingStatus)) {
      return res.status(400).json({ success: false, message: "Invalid booking status" });
    }
    const booking = await Booking.findByIdAndUpdate(req.params.id, { bookingStatus }, { new: true })
      .populate("user", "name email")
      .populate("service", "serviceName");
    if (!booking) return res.status(404).json({ success: false, message: "Booking not found" });
    res.json({ success: true, message: "Booking status updated", data: booking });
  } catch (error) {
    res.status(400).json({ success: false, message: "Could not update booking status", error: error.message });
  }
};

module.exports = {
  getStats,
  getAllUsers,
  updateUserRole,
  deleteUser,
  getAllBookings,
  updateBookingStatus,
};
