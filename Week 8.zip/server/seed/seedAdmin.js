// Run with: npm run seed:admin
// Creates an admin account (or promotes an existing account to admin) using
// ADMIN_NAME / ADMIN_EMAIL / ADMIN_PASSWORD from server/.env.
require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const connectDB = require("../config/db");
const User = require("../models/User");

const run = async () => {
  const name = process.env.ADMIN_NAME || "Voyage Admin";
  const email = (process.env.ADMIN_EMAIL || "admin@voyage.com").toLowerCase().trim();
  const password = process.env.ADMIN_PASSWORD || "admin123";

  await connectDB();

  let user = await User.findOne({ email });

  if (user) {
    user.role = "admin";
    await user.save();
    console.log(`Existing account "${email}" promoted to admin.`);
  } else {
    const hashedPassword = await bcrypt.hash(password, 12);
    user = await User.create({ name, email, password: hashedPassword, role: "admin" });
    console.log(`Admin account created.\n  Email: ${email}\n  Password: ${password}`);
  }

  await mongoose.disconnect();
  process.exit(0);
};

run().catch((error) => {
  console.error("Could not seed admin account:", error.message);
  process.exit(1);
});
