const express = require("express");
const router = express.Router();
const { protect, adminOnly } = require("../middleware/authMiddleware");
const {
  getDestinations,
  getDestinationsByCategory,
  getDestinationById,
  createDestination,
  updateDestination,
  deleteDestination,
} = require("../controllers/destinationController");

router.route("/").get(getDestinations).post(protect, adminOnly, createDestination);

router.get("/category/:category", getDestinationsByCategory);

router
  .route("/:id")
  .get(getDestinationById)
  .put(protect, adminOnly, updateDestination)
  .delete(protect, adminOnly, deleteDestination);

module.exports = router;
