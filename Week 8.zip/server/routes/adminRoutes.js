const express = require("express");
const { protect, adminOnly } = require("../middleware/authMiddleware");
const {
  getStats,
  getAllUsers,
  updateUserRole,
  deleteUser,
  getAllBookings,
  updateBookingStatus,
} = require("../controllers/adminController");

const router = express.Router();

router.use(protect, adminOnly);

router.get("/stats", getStats);
router.get("/users", getAllUsers);
router.patch("/users/:id/role", updateUserRole);
router.delete("/users/:id", deleteUser);
router.get("/bookings", getAllBookings);
router.patch("/bookings/:id/status", updateBookingStatus);

module.exports = router;
