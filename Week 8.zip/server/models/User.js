const mongoose = require("mongoose");

const preferenceSchema = new mongoose.Schema(
  {
    budget: { type: Number, min: 0, default: 0 },
    travelStyle: {
      type: String,
      enum: ["", "Adventure", "Relaxation", "Cultural", "Luxury", "Nature", "City", "Family", "Budget"],
      default: "",
      trim: true,
    },
    preferredCategory: { type: String, default: "", trim: true },
    preferredLocation: { type: String, default: "", trim: true },
    tripDuration: { type: Number, min: 1, max: 60, default: 3 },
  },
  { _id: false }
);

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Name is required"],
      trim: true,
      minlength: 2,
      maxlength: 80,
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
      minlength: 6,
      select: false,
    },
    profileImage: { type: String, default: "", trim: true },
    bio: { type: String, default: "", maxlength: 500, trim: true },
    role: { type: String, enum: ["user", "admin"], default: "user" },
    preferences: { type: preferenceSchema, default: () => ({}) },
    favorites: [{ type: mongoose.Schema.Types.ObjectId, ref: "Destination" }],
    recentlyViewed: [
      {
        destination: { type: mongoose.Schema.Types.ObjectId, ref: "Destination" },
        viewedAt: { type: Date, default: Date.now },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);
