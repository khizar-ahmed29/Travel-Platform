import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import StateMessage from "../components/StateMessage.jsx";
import { getService } from "../services/api.js";
import { useAuth } from "../context/AuthContext.jsx";

function ServiceDetails() {
  const { id } = useParams(); const navigate = useNavigate(); const { user } = useAuth();
  const [service, setService] = useState(null); const [error, setError] = useState("");
  useEffect(()=>{ getService(id).then(r=>setService(r.data)).catch(e=>setError(e.response?.data?.message||"Could not load service.")); },[id]);
  if(error) return <><Navbar/><main className="section"><StateMessage tone="error">{error}</StateMessage></main></>;
  if(!service) return <><Navbar/><main className="section"><StateMessage tone="info">Loading service…</StateMessage></main></>;
  return <><Navbar/><main><section className="service-detail">
    <div className="service-detail__image"><img src={service.image || "https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=80"} alt={service.serviceName}/></div>
    <div className="service-detail__content"><p className="eyebrow"><span className="eyebrow__code">{service.category}</span> {service.location}</p><h1>{service.serviceName}</h1><div className="service-detail__price"><span>★ {Number(service.rating||0).toFixed(1)}</span><strong>PKR {Number(service.price).toLocaleString()} <small>/ person</small></strong></div><p>{service.description}</p><div className="feature-list">{(service.features||[]).map(f=><div key={f}>✓ {f}</div>)}</div>{!service.availability && <StateMessage tone="error">This service is currently unavailable.</StateMessage>}{service.availability && (user ? <button className="btn btn--primary btn--large" onClick={()=>navigate(`/services/${id}/book`)}>Book Now</button> : <Link className="btn btn--primary btn--large" to="/login">Log in to book</Link>)}</div>
  </section></main><Footer/></>;
}
export default ServiceDetails;
