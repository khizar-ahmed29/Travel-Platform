const express = require("express");
const { protect } = require("../middleware/authMiddleware");
const { getPreferences, savePreferences, getRecommendations } = require("../controllers/recommendationController");

const router = express.Router();
router.use(protect);
router.get("/preferences", getPreferences);
router.post("/preferences", savePreferences);
router.put("/preferences", savePreferences);
router.get("/", getRecommendations);

module.exports = router;
