const User = require("../models/User");
const Destination = require("../models/Destination");
const Service = require("../models/Service");
const Booking = require("../models/Booking");

const normalize = (value = "") => String(value).trim().toLowerCase();
const includesText = (value, search) => normalize(value).includes(normalize(search));

const CATEGORY_STYLE = {
  beach: ["Relaxation", "Luxury", "Family"],
  mountain: ["Adventure", "Nature"],
  city: ["City", "Luxury", "Family"],
  cultural: ["Cultural", "Family"],
  adventure: ["Adventure", "Nature"],
  wildlife: ["Nature", "Adventure"],
  historical: ["Cultural"],
  island: ["Relaxation", "Luxury", "Nature"],
};

const DURATION_BY_CATEGORY = {
  beach: 4,
  mountain: 4,
  city: 3,
  cultural: 3,
  adventure: 5,
  wildlife: 4,
  historical: 2,
  island: 5,
};

function scoreDestination(destination, preferences, signals) {
  let score = 0;
  let maxScore = 10;
  const reasons = [];
  const category = normalize(destination.category);

  if (preferences.preferredCategory && normalize(preferences.preferredCategory) === category) {
    score += 3;
    reasons.push(`matches your ${destination.category} category preference`);
  }

  const styles = CATEGORY_STYLE[category] || [];
  if (preferences.travelStyle && styles.some((style) => normalize(style) === normalize(preferences.travelStyle))) {
    score += 3;
    reasons.push(`fits your ${preferences.travelStyle.toLowerCase()} travel style`);
  }

  if (preferences.preferredLocation && (
    includesText(destination.city, preferences.preferredLocation) ||
    includesText(destination.country, preferences.preferredLocation)
  )) {
    score += 2;
    reasons.push(`is in your preferred location`);
  }

  const recommendedDays = DURATION_BY_CATEGORY[category] || 3;
  if (preferences.tripDuration && Math.abs(Number(preferences.tripDuration) - recommendedDays) <= 1) {
    score += 1;
    reasons.push(`works well for about ${recommendedDays} days`);
  }

  if (signals.favoriteIds.has(String(destination._id))) {
    score += 1;
    reasons.push("is already one of your favorites");
  } else if (signals.recentIds.has(String(destination._id))) {
    score += 0.5;
    reasons.push("is similar to places you recently explored");
  }

  if (!reasons.length && destination.featured) {
    score += 1;
    reasons.push("is a highly featured destination");
  }

  return {
    item: destination,
    score,
    match: Math.min(100, Math.round((score / maxScore) * 100)),
    reasons,
  };
}

function scoreService(service, preferences, signals) {
  let score = 0;
  const maxScore = 11;
  const reasons = [];

  if (preferences.preferredCategory && normalize(service.category) === normalize(preferences.preferredCategory)) {
    score += 3;
    reasons.push(`matches your ${service.category} category preference`);
  }

  if (preferences.preferredLocation && includesText(service.location, preferences.preferredLocation)) {
    score += 2;
    reasons.push("is available in your preferred location");
  }

  if (preferences.budget && Number(service.price) <= Number(preferences.budget)) {
    score += 2;
    reasons.push(`fits within your budget of ${Number(preferences.budget).toLocaleString()}`);
  }

  const categoryText = normalize(service.category);
  const featureText = normalize((service.features || []).join(" "));
  if (preferences.travelStyle && (
    categoryText.includes(normalize(preferences.travelStyle)) ||
    featureText.includes(normalize(preferences.travelStyle))
  )) {
    score += 3;
    reasons.push(`supports your ${preferences.travelStyle.toLowerCase()} travel style`);
  }

  if (signals.bookedCategories.has(categoryText)) {
    score += 1;
    reasons.push("is similar to services you booked before");
  }

  if (!reasons.length && service.rating >= 4.5) {
    score += 1;
    reasons.push("is highly rated by travelers");
  }

  return {
    item: service,
    score,
    match: Math.min(100, Math.round((score / maxScore) * 100)),
    reasons,
  };
}

function validatePreferences(payload) {
  const errors = [];
  if (payload.budget !== undefined && (Number.isNaN(Number(payload.budget)) || Number(payload.budget) < 0)) {
    errors.push("Budget must be a positive number");
  }
  if (payload.tripDuration !== undefined) {
    const duration = Number(payload.tripDuration);
    if (!Number.isInteger(duration) || duration < 1 || duration > 60) errors.push("Trip duration must be between 1 and 60 days");
  }
  return errors;
}

const getPreferences = async (req, res) => {
  try {
    const user = await User.findById(req.userId).select("preferences");
    if (!user) return res.status(404).json({ success: false, message: "User not found" });
    res.json({ success: true, data: user.preferences || {} });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not load preferences", error: error.message });
  }
};

const savePreferences = async (req, res) => {
  try {
    const errors = validatePreferences(req.body);
    if (errors.length) return res.status(400).json({ success: false, message: errors[0], errors });

    const allowed = ["budget", "travelStyle", "preferredCategory", "preferredLocation", "tripDuration"];
    const updates = {};
    allowed.forEach((field) => {
      if (req.body[field] !== undefined) updates[`preferences.${field}`] = req.body[field];
    });

    const user = await User.findByIdAndUpdate(req.userId, { $set: updates }, { new: true, runValidators: true }).select("preferences");
    if (!user) return res.status(404).json({ success: false, message: "User not found" });
    res.json({ success: true, message: "Preferences saved", data: user.preferences });
  } catch (error) {
    res.status(400).json({ success: false, message: "Could not save preferences", error: error.message });
  }
};

const getRecommendations = async (req, res) => {
  try {
    const user = await User.findById(req.userId).populate("favorites").populate("recentlyViewed.destination");
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    const [destinations, services, bookings] = await Promise.all([
      Destination.find({}),
      Service.find({ availability: true }),
      Booking.find({ user: req.userId, bookingStatus: { $ne: "Cancelled" } }).populate("service"),
    ]);

    const signals = {
      favoriteIds: new Set((user.favorites || []).map((item) => String(item._id))),
      recentIds: new Set((user.recentlyViewed || []).filter((item) => item.destination).map((item) => String(item.destination._id))),
      bookedCategories: new Set(bookings.filter((booking) => booking.service).map((booking) => normalize(booking.service.category))),
    };

    const preferences = user.preferences || {};
    const destinationResults = destinations
      .map((item) => scoreDestination(item, preferences, signals))
      .sort((a, b) => b.score - a.score || (b.item.rating || 0) - (a.item.rating || 0))
      .slice(0, 8);

    const serviceResults = services
      .map((item) => scoreService(item, preferences, signals))
      .sort((a, b) => b.score - a.score || (b.item.rating || 0) - (a.item.rating || 0))
      .slice(0, 8);

    res.json({
      success: true,
      data: {
        preferences,
        destinations: destinationResults,
        services: serviceResults,
        meta: {
          destinationsAvailable: destinations.length,
          servicesAvailable: services.length,
          usedFavorites: signals.favoriteIds.size,
          usedRecentViews: signals.recentIds.size,
          usedBookings: bookings.length,
        },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not generate recommendations", error: error.message });
  }
};

module.exports = { getPreferences, savePreferences, getRecommendations };
