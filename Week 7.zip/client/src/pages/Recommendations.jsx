import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar.jsx";
import Footer from "../components/Footer.jsx";
import StateMessage from "../components/StateMessage.jsx";
import { getPreferences, getRecommendations, savePreferences } from "../services/api.js";

const defaultPreferences = {
  budget: "",
  travelStyle: "",
  preferredCategory: "",
  preferredLocation: "",
  tripDuration: 3,
};

const styles = ["", "Adventure", "Relaxation", "Cultural", "Luxury", "Nature", "City", "Family", "Budget"];
const categories = ["", "Beach", "Mountain", "City", "Cultural", "Adventure", "Wildlife", "Historical", "Island", "Hotel", "Transport", "Tour", "Guide"];

function MatchBadge({ value }) {
  return <span className="match-badge">{value}% Match</span>;
}

function RecommendationCard({ result, type }) {
  const item = result.item;
  const isDestination = type === "destination";
  const title = isDestination ? item.name : item.serviceName;
  const image = isDestination ? item.imageUrl : item.image;
  const location = isDestination ? `${item.city}, ${item.country}` : item.location;
  const url = isDestination ? `/destinations/${item._id}` : `/services/${item._id}`;

  return (
    <article className="recommend-card">
      <div className="recommend-card__image">
        {image ? <img src={image} alt={title} /> : <div className="recommend-card__placeholder">✈</div>}
        <MatchBadge value={result.match} />
      </div>
      <div className="recommend-card__body">
        <div className="recommend-card__topline">
          <span>{item.category}</span>
          <span>★ {Number(item.rating || 0).toFixed(1)}</span>
        </div>
        <h3>{title}</h3>
        <p className="recommend-card__location">{location}</p>
        {!isDestination && <p className="recommend-card__price">Price: {Number(item.price || 0).toLocaleString()}</p>}
        <p className="recommend-card__reason">
          {result.reasons.length ? `Recommended because it ${result.reasons.slice(0, 2).join(" and ")}.` : "Recommended based on overall traveler rating and availability."}
        </p>
        <Link className="btn btn--sm btn--primary" to={url}>View details</Link>
      </div>
    </article>
  );
}

function Recommendations() {
  const [preferences, setPreferences] = useState(defaultPreferences);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const hasPreferences = useMemo(() => Boolean(
    preferences.budget || preferences.travelStyle || preferences.preferredCategory || preferences.preferredLocation || preferences.tripDuration
  ), [preferences]);

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const [prefRes, recRes] = await Promise.all([getPreferences(), getRecommendations()]);
      setPreferences({ ...defaultPreferences, ...prefRes.data, budget: prefRes.data?.budget || "" });
      setData(recRes.data);
    } catch (err) {
      setError(err.response?.data?.message || "Could not load recommendations");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const submit = async (event) => {
    event.preventDefault();
    setSaving(true);
    setError("");
    setMessage("");
    try {
      const payload = {
        ...preferences,
        budget: preferences.budget === "" ? 0 : Number(preferences.budget),
        tripDuration: Number(preferences.tripDuration),
      };
      await savePreferences(payload);
      const recRes = await getRecommendations();
      setData(recRes.data);
      setMessage("Preferences saved. Your recommendations have been refreshed.");
    } catch (err) {
      setError(err.response?.data?.message || "Could not save preferences");
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <Navbar />
      <main>
        <section className="recommend-hero">
          <div>
            <p className="eyebrow eyebrow--light"><span className="eyebrow__code">SMART</span> Personalized travel</p>
            <h1>Recommendations made for you.</h1>
            <p>Tell us how you like to travel. Voyage combines those preferences with your favorites, bookings and recently viewed places to rank suitable destinations and services.</p>
          </div>
        </section>

        <section className="section">
          <div className="section__inner recommend-layout">
            <aside className="preferences-panel">
              <p className="eyebrow"><span className="eyebrow__code">01</span> Preferences</p>
              <h2>Personalize your results</h2>
              <form onSubmit={submit} className="preferences-form">
                <label className="form-field">Maximum budget
                  <input type="number" min="0" placeholder="e.g. 25000" value={preferences.budget} onChange={(e) => setPreferences({ ...preferences, budget: e.target.value })} />
                </label>
                <label className="form-field">Travel style
                  <select value={preferences.travelStyle} onChange={(e) => setPreferences({ ...preferences, travelStyle: e.target.value })}>
                    {styles.map((value) => <option key={value} value={value}>{value || "Any style"}</option>)}
                  </select>
                </label>
                <label className="form-field">Preferred category
                  <select value={preferences.preferredCategory} onChange={(e) => setPreferences({ ...preferences, preferredCategory: e.target.value })}>
                    {categories.map((value) => <option key={value} value={value}>{value || "Any category"}</option>)}
                  </select>
                </label>
                <label className="form-field">Preferred location
                  <input placeholder="e.g. Karachi, Turkey" value={preferences.preferredLocation} onChange={(e) => setPreferences({ ...preferences, preferredLocation: e.target.value })} />
                </label>
                <label className="form-field">Trip duration (days)
                  <input type="number" min="1" max="60" required value={preferences.tripDuration} onChange={(e) => setPreferences({ ...preferences, tripDuration: e.target.value })} />
                </label>
                <button className="btn btn--primary" disabled={saving}>{saving ? "Saving…" : "Save & refresh"}</button>
              </form>
              {message && <StateMessage tone="info">{message}</StateMessage>}
            </aside>

            <div className="recommend-results">
              {loading && <StateMessage tone="info">Finding the best matches for you…</StateMessage>}
              {error && <StateMessage tone="error">{error}</StateMessage>}
              {!loading && !error && data && (
                <>
                  <div className="recommend-summary">
                    <div><strong>{data.destinations.length}</strong><span>Destination matches</span></div>
                    <div><strong>{data.services.length}</strong><span>Service matches</span></div>
                    <div><strong>{data.meta.usedFavorites + data.meta.usedBookings + data.meta.usedRecentViews}</strong><span>Personal signals used</span></div>
                  </div>

                  <div className="section__head recommendation-heading">
                    <p className="eyebrow"><span className="eyebrow__code">02</span> Destinations</p>
                    <h2 className="section__title">Recommended destinations</h2>
                  </div>
                  {!data.destinations.length ? (
                    <StateMessage tone="info">No destinations are available yet.</StateMessage>
                  ) : (
                    <div className="recommend-grid">
                      {data.destinations.map((result) => <RecommendationCard key={result.item._id} result={result} type="destination" />)}
                    </div>
                  )}

                  <div className="section__head recommendation-heading recommendation-heading--spaced">
                    <p className="eyebrow"><span className="eyebrow__code">03</span> Services</p>
                    <h2 className="section__title">Recommended services</h2>
                  </div>
                  {!data.services.length ? (
                    <StateMessage tone="info">No available travel services were found.</StateMessage>
                  ) : (
                    <div className="recommend-grid">
                      {data.services.map((result) => <RecommendationCard key={result.item._id} result={result} type="service" />)}
                    </div>
                  )}

                  {!hasPreferences && <StateMessage tone="info">Add more preferences to make the ranking more personal.</StateMessage>}
                </>
              )}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

export default Recommendations;
