import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

const NAV_LINKS = [
  { label: "Destinations", href: "/#destinations" },
  { label: "Featured", href: "/#featured" },
  { label: "Categories", href: "/#categories" },
  { label: "About", href: "/#about" },
  { label: "Services", href: "/services" },
];

function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const signOut = () => {
    logout();
    navigate("/");
  };

  return (
    <header className={`nav ${scrolled ? "nav--scrolled" : ""}`}>
      <div className="nav__inner">
        <Link to="/" className="nav__brand">
          <span className="nav__brand-mark" aria-hidden="true">✈</span>
          Voyage
        </Link>

        <nav className="nav__links" aria-label="Primary">
          {NAV_LINKS.map((link) => <a key={link.href} href={link.href}>{link.label}</a>)}
          {user && <Link to="/dashboard">Dashboard</Link>}
          {user && <Link to="/favorites">Favorites</Link>}
          {user && <Link to="/trips">Trips</Link>}
          {user && <Link to="/bookings">Bookings</Link>}
          {user && <Link to="/recommendations">For You</Link>}
        </nav>

        <div className="nav__account">
          {user ? (
            <>
              <Link to="/profile" className="nav__user">
                {user.profileImage ? <img src={user.profileImage} alt="" /> : <span>{user.name?.charAt(0)?.toUpperCase()}</span>}
                <strong>{user.name?.split(" ")[0]}</strong>
              </Link>
              <button className="btn btn--sm btn--ghost" onClick={signOut}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn btn--sm btn--ghost">Login</Link>
              <Link to="/register" className="btn btn--sm btn--primary">Sign up</Link>
            </>
          )}
        </div>

        <button className="nav__toggle" aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen((v) => !v)}>
          <span /><span /><span />
        </button>
      </div>

      {open && (
        <div className="nav__mobile">
          {NAV_LINKS.map((link) => <a key={link.href} href={link.href} onClick={() => setOpen(false)}>{link.label}</a>)}
          {user ? (
            <>
              <Link to="/dashboard" onClick={() => setOpen(false)}>Dashboard</Link>
              <Link to="/favorites" onClick={() => setOpen(false)}>Favorites</Link>
              <Link to="/trips" onClick={() => setOpen(false)}>Trips</Link>
              <Link to="/bookings" onClick={() => setOpen(false)}>Bookings</Link>
              <Link to="/recommendations" onClick={() => setOpen(false)}>For You</Link>
              <Link to="/profile" onClick={() => setOpen(false)}>Profile</Link>
              <button className="btn btn--sm btn--ghost" onClick={signOut}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" onClick={() => setOpen(false)}>Login</Link>
              <Link to="/register" className="btn btn--sm btn--primary" onClick={() => setOpen(false)}>Sign up</Link>
            </>
          )}
        </div>
      )}
    </header>
  );
}

export default Navbar;
