import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const TOKEN_KEY = "voyage_token";

const api = axios.create({
  baseURL: API_URL,
  headers: { "Content-Type": "application/json" },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export const getDestinations = (params = {}) =>
  api.get("/destinations", { params }).then((res) => res.data);

export const getDestinationById = (id) =>
  api.get(`/destinations/${id}`).then((res) => res.data);

export const createDestination = (payload) =>
  api.post("/destinations", payload).then((res) => res.data);

export const updateDestination = (id, payload) =>
  api.put(`/destinations/${id}`, payload).then((res) => res.data);

export const deleteDestination = (id) =>
  api.delete(`/destinations/${id}`).then((res) => res.data);

export const getDashboard = () =>
  api.get("/users/dashboard").then((res) => res.data);

export const getFavorites = () =>
  api.get("/users/favorites").then((res) => res.data);

export const addFavorite = (destinationId) =>
  api.post(`/users/favorites/${destinationId}`).then((res) => res.data);

export const removeFavorite = (destinationId) =>
  api.delete(`/users/favorites/${destinationId}`).then((res) => res.data);

export const recordRecentlyViewed = (destinationId) =>
  api.post(`/users/recently-viewed/${destinationId}`).then((res) => res.data);

export const updateProfile = (payload) =>
  api.put("/users/profile", payload).then((res) => res.data);

export default api;


// Trip & itinerary management
export const getTrips = () =>
  api.get("/trips").then((res) => res.data);

export const getTrip = (tripId) =>
  api.get(`/trips/${tripId}`).then((res) => res.data);

export const createTrip = (payload) =>
  api.post("/trips", payload).then((res) => res.data);

export const updateTrip = (tripId, payload) =>
  api.put(`/trips/${tripId}`, payload).then((res) => res.data);

export const deleteTrip = (tripId) =>
  api.delete(`/trips/${tripId}`).then((res) => res.data);

export const addActivity = (tripId, payload) =>
  api.post(`/trips/${tripId}/activities`, payload).then((res) => res.data);

export const updateActivity = (tripId, activityId, payload) =>
  api.put(`/trips/${tripId}/activities/${activityId}`, payload).then((res) => res.data);

export const deleteActivity = (tripId, activityId) =>
  api.delete(`/trips/${tripId}/activities/${activityId}`).then((res) => res.data);


// Travel services & bookings
export const getServices = (params = {}) =>
  api.get("/services", { params }).then((res) => res.data);
export const getService = (serviceId) =>
  api.get(`/services/${serviceId}`).then((res) => res.data);
export const createService = (payload) =>
  api.post("/services", payload).then((res) => res.data);
export const updateService = (serviceId, payload) =>
  api.put(`/services/${serviceId}`, payload).then((res) => res.data);
export const deleteService = (serviceId) =>
  api.delete(`/services/${serviceId}`).then((res) => res.data);
export const createBooking = (payload) =>
  api.post("/bookings", payload).then((res) => res.data);
export const getBookings = () =>
  api.get("/bookings").then((res) => res.data);
export const getBooking = (bookingId) =>
  api.get(`/bookings/${bookingId}`).then((res) => res.data);
export const updateBooking = (bookingId, payload) =>
  api.put(`/bookings/${bookingId}`, payload).then((res) => res.data);
export const cancelBooking = (bookingId) =>
  api.patch(`/bookings/${bookingId}/cancel`).then((res) => res.data);

// Reviews & ratings
export const getReviews = (type, targetId, params = {}) => api.get("/reviews", { params: { type, id: targetId, ...params } }).then(res => res.data);
export const getReview = (reviewId) => api.get(`/reviews/${reviewId}`).then(res => res.data);
export const createReview = (payload) => api.post("/reviews", payload).then(res => res.data);
export const updateReview = (reviewId, payload) => api.put(`/reviews/${reviewId}`, payload).then(res => res.data);
export const deleteReview = (reviewId) => api.delete(`/reviews/${reviewId}`).then(res => res.data);
export const markReviewHelpful = (reviewId) => api.patch(`/reviews/${reviewId}/helpful`).then(res => res.data);

// Personalized travel recommendations
export const getPreferences = () =>
  api.get("/recommendations/preferences").then((res) => res.data);
export const savePreferences = (payload) =>
  api.put("/recommendations/preferences", payload).then((res) => res.data);
export const getRecommendations = () =>
  api.get("/recommendations").then((res) => res.data);
