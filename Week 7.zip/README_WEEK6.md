# Week 6 — Personalized Travel Recommendation System

This version adds a rule-based recommendation module to Voyage.

## Features

- User preferences stored in MongoDB: budget, travel style, category, location and trip duration
- Protected preference APIs for reading, saving and updating preferences
- Recommendation API that ranks both destinations and travel services
- Scoring based on category, budget, travel style, location and duration
- Personalization signals from favorites, recent destination views and previous bookings
- Match percentage and human-readable reasons for every recommendation
- React `/recommendations` page with preference form, loading state, errors and empty states
- "For You" navigation item for authenticated users

## APIs

- `GET /api/recommendations/preferences`
- `POST /api/recommendations/preferences`
- `PUT /api/recommendations/preferences`
- `GET /api/recommendations`

## Run

Use the same `.env` files as the previous project version.

Backend:

```bash
cd server
npm install
npm run dev
```

Frontend:

```bash
cd client
npm install
npm run dev
```

Log in and open **For You** in the navigation bar to set preferences and see personalized recommendations.
